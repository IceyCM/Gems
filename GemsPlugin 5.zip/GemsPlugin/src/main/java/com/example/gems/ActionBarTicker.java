package com.example.gems;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

import java.util.List;

/** Shows the selected ability's cooldown on the action bar while holding a gem. */
public class ActionBarTicker implements Runnable {

    private final GemsPlugin plugin;

    public ActionBarTicker(GemsPlugin plugin) {
        this.plugin = plugin;
    }

    @Override
    public void run() {
        GemManager gems = plugin.gems();
        Cooldowns cd = plugin.cooldowns();
        cd.tick(); // fire ready notifications once per second

        for (Player p : Bukkit.getOnlinePlayers()) {
            if (gems.isRolling(p)) continue;
            ItemStack item = p.getInventory().getItemInMainHand();
            GemType type = gems.getGem(item);
            if (type == null) {
                item = p.getInventory().getItemInOffHand();
                type = gems.getGem(item);
            }
            if (type == null) continue;

            List<String> names = Abilities.names(type);
            if (names.isEmpty()) continue;

            int sel = gems.getSelected(item, names.size());
            String name = names.get(sel);
            String cdKey = cdKey(type, sel);
            if (cdKey == null) continue;

            long left = cd.remainingMs(p.getUniqueId(), cdKey);
            String text = left > 0
                    ? name + ": " + Cooldowns.format(left)
                    : name + ": Ready";
            NamedTextColor color = left > 0 ? NamedTextColor.RED : NamedTextColor.GREEN;
            p.sendActionBar(Component.text(text, color));
        }
    }

    /** Maps gem type + ability index to the cooldown key used in Cooldowns. */
    static String cdKey(GemType type, int idx) {
        return switch (type) {
            case STRENGTH -> new String[]{"chad","fractured","smash","frailer"}[idx];
            case PUFF -> new String[]{"puff_dash","puff_slam","puff_tornado","puff_airlock","puff_updraft"}[idx];
            case SPEED -> new String[]{"spd_recall","spd_speedy","spd_blur","spd_dazzle","spd_overdrive"}[idx];
            default -> null;
        };
    }
}
