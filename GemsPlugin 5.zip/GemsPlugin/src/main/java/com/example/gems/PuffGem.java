package com.example.gems;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.*;
import org.bukkit.entity.*;
import org.bukkit.event.*;
import org.bukkit.event.block.Action;
import org.bukkit.event.entity.*;
import org.bukkit.event.player.*;
import org.bukkit.inventory.ItemStack;
import org.bukkit.potion.*;
import org.bukkit.scheduler.BukkitTask;
import org.bukkit.util.Vector;

import java.util.*;

public class PuffGem implements Listener {

    private final GemsPlugin plugin;
    private final GemManager gems;
    private final Cooldowns cd;
    private final Status status;
    private final Deaths deaths;

    private final Set<UUID> jumping = new HashSet<>();
    private final Map<UUID, Long> lastJumpTime = new HashMap<>();
    private final Map<UUID, BukkitTask> jumpTrail = new HashMap<>();
    private final Map<UUID, BukkitTask> slamTask = new HashMap<>();
    private final Map<UUID, BukkitTask> tornadoTask = new HashMap<>();
    private final Map<UUID, Long> airLockUntil = new HashMap<>();
    private final Map<UUID, Long> windBlockUntil = new HashMap<>();
    private final Map<UUID, Integer> upwindHits = new HashMap<>();
    private final Set<UUID> awaiting = new HashSet<>();
    private int internalDmg = 0;

    private static final String[] KEYS = {"dash","slam","tornado","airlock","updraft"};
    private static final double[] COOLDOWNS = {30,75,90,100,120};

    public PuffGem(GemsPlugin plugin) {
        this.plugin = plugin;
        this.gems = plugin.gems();
        this.cd = plugin.cooldowns();
        this.status = plugin.status();
        this.deaths = plugin.deaths();
    }

    public void start() {
        Bukkit.getScheduler().runTaskTimer(plugin, this::tick, 1L, 1L);
    }

    private boolean hasPuff(Player p) { return gems.getGem(p.getInventory().getItemInMainHand()) == GemType.PUFF || gems.getGem(p.getInventory().getItemInOffHand()) == GemType.PUFF; }
    private double cd(String k, double def) { return plugin.getConfig().getDouble("puff."+k, def); }
    private long ms(String k, double def) { return (long)(cd(k,def)*1000); }
    private int ticks(String k, double def) { return (int)Math.max(1, cd(k,def)*20); }
    private static long now() { return System.currentTimeMillis(); }
    private void bar(Player p, String msg, NamedTextColor c) { p.sendActionBar(Component.text(msg, c)); }

    private void hurt(LivingEntity t, double hearts, Player src, String deathKey) {
        if (t.equals(src)) return;
        internalDmg++;
        try {
            double hp = hearts * 2.0;
            t.setNoDamageTicks(0);
            t.damage(0.001, src);
            t.setHealth(Math.max(0, t.getHealth() - hp));
            if (t.getHealth() <= 0 && t instanceof Player v) {
                deaths.record(v.getUniqueId(), src.getUniqueId(), deathKey);
            }
        } finally { internalDmg--; }
    }

    // ======== Passive: no fall damage
    @EventHandler(ignoreCancelled = true)
    public void onFall(EntityDamageEvent e) {
        if (e.getCause() != EntityDamageEvent.DamageCause.FALL) return;
        if (e.getEntity() instanceof Player p && hasPuff(p)) e.setCancelled(true);
    }

    // ======== Passive: double jump
    @EventHandler
    public void onToggleFlight(PlayerToggleFlightEvent e) {
        Player p = e.getPlayer();
        if (!hasPuff(p) || !gems.usable(p) || p.getGameMode() == GameMode.CREATIVE || p.getGameMode() == GameMode.SPECTATOR) return;
        if (!jumping.contains(p.getUniqueId())) return;
        e.setCancelled(true);
        UUID id = p.getUniqueId();
        long left = cd.remainingMs(id, "djump");
        if (left > 0) { p.sendMessage(Component.text("Double jump on cooldown: " + Cooldowns.format(left), NamedTextColor.RED)); return; }
        Vector dir = p.getLocation().getDirection().normalize();
        p.setVelocity(new Vector(dir.getX()*0.209, 0.803, dir.getZ()*0.209));
        cd.start(id, "djump", ms("djump.cooldown-seconds", 6.0));
        startTrail(p);
    }



    private void startTrail(Player p) {
        stopTrail(p);
        BukkitTask t = Bukkit.getScheduler().runTaskTimer(plugin, () -> {
            if (p.isOnGround() || !p.isOnline()) { stopTrail(p); return; }
            p.getWorld().spawnParticle(Particle.POOF, p.getLocation(), 6, 0.3,0.3,0.3,0.01);
        }, 0, 1);
        jumpTrail.put(p.getUniqueId(), t);
    }

    private void stopTrail(Player p) {
        BukkitTask old = jumpTrail.remove(p.getUniqueId());
        if (old != null) old.cancel();
    }

    // ======== Passive: permanent Speed
    // ======== Passive: Upwind
    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onHit(EntityDamageByEntityEvent e) {
        if (internalDmg > 0 || !(e.getDamager() instanceof Player a) || !(e.getEntity() instanceof Player t)) return;
        if (!hasPuff(a) || !gems.usable(a) || gems.isRolling(a)) return;
        ItemStack main = a.getInventory().getItemInMainHand();
        if (main == null || !main.getType().name().endsWith("_SWORD")) return;
        UUID id = a.getUniqueId();
        int hits = upwindHits.merge(id, 1, Integer::sum);
        if (hits >= plugin.getConfig().getInt("puff.upwind.hits", 15)) {
            upwindHits.put(id, 0);
            t.setVelocity(t.getVelocity().add(new Vector(0,0.5,0)));
            int dur = ticks("upwind.slowfall-seconds", 3.0);
            t.addPotionEffect(new PotionEffect(PotionEffectType.SLOW_FALLING, dur, 0));
        }
    }

    // ======== Auto-enchant: Feather Falling IV on boots
    private final Map<UUID, Long> sneakStart = new HashMap<>();

    @EventHandler
    public void onSneak(PlayerToggleSneakEvent e) {
        UUID id = e.getPlayer().getUniqueId();
        if (e.isSneaking()) sneakStart.put(id, now());
        else sneakStart.remove(id);
    }

    // ======== Activate ability
    public void activate(Player p, int idx) {
        if (idx < 0 || idx >= KEYS.length) return;
        String key = KEYS[idx];
        UUID id = p.getUniqueId();
        long left = cd.remainingMs(id, "puff_" + key);
        String name = Abilities.names(GemType.PUFF).get(idx);
        if (left > 0) { bar(p, name + " on cooldown: " + Cooldowns.format(left), NamedTextColor.RED); return; }
        switch (idx) {
            case 0 -> dash(p);
            case 1 -> armSlam(p);
            case 2 -> tornado(p);
            case 3 -> airLock(p);
            case 4 -> updraft(p);
        }
    }

    private void startCd(Player p, int idx) {
        double factor = plugin.energy().cooldownFactor(p);
        String name = Abilities.names(GemType.PUFF).get(idx);
        cd.start(p.getUniqueId(), "puff_" + KEYS[idx], (long)(COOLDOWNS[idx] * factor * 1000), name);
    }

    // ======== Dash
    private void dash(Player p) {
        double dist = cd("dash.distance", 15.0) * plugin.energy().reachFactor(p);
        Vector dir = p.getLocation().getDirection().normalize().multiply(1.5);
        p.setVelocity(dir.clone().multiply(dist / 15.0 * 1.4).setY(dir.getY() * 0.6 + 0.3));
        Set<UUID> hit = new HashSet<>();
        final int[] age = {0};
        Bukkit.getScheduler().runTaskTimer(plugin, task -> {
            age[0]++;
            if (!p.isOnline() || age[0] > 60) { task.cancel(); return; } // 3s timeout
            for (Entity en : p.getNearbyEntities(1.5,1.5,1.5)) {
                if (!(en instanceof Player t) || t.equals(p) || hit.contains(t.getUniqueId())) continue;
                hit.add(t.getUniqueId());
                hurt(t, cd("dash.damage-hearts",2.5), p, "puff.dash");
                windBlock(t, (long)(cd("dash.windblock-seconds",5.0)*1000));
            }
            p.getWorld().spawnParticle(Particle.POOF, p.getLocation(),4,0.2,0.2,0.2,0.01);
            if (p.isOnGround()) task.cancel();
        }, 0, 1);
        startCd(p, 0);
        bar(p, "Dash!", NamedTextColor.AQUA);
    }

    // ======== Puff Slam
    private void armSlam(Player p) {
        awaiting.add(p.getUniqueId());
        bar(p, "Hit a player to Puff Slam them!", NamedTextColor.AQUA);
        Bukkit.getScheduler().runTaskLater(plugin, () -> {
            if (awaiting.remove(p.getUniqueId())) bar(p, "Puff Slam expired.", NamedTextColor.GRAY);
        }, (long)(cd("slam.arm-seconds",10.0)*20));
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onSlamHit(EntityDamageByEntityEvent e) {
        if (internalDmg > 0 || !(e.getDamager() instanceof Player a) || !(e.getEntity() instanceof Player t)) return;
        if (!awaiting.remove(a.getUniqueId())) return;
        e.setCancelled(true);
        UUID tid = t.getUniqueId();
        double up = cd("slam.height", 22.0);
        t.setVelocity(new Vector(0, up * 0.08, 0));

        BukkitTask trail = Bukkit.getScheduler().runTaskTimer(plugin, task -> {
            if (!t.isOnline()) { task.cancel(); return; }
            t.getWorld().spawnParticle(Particle.POOF, t.getLocation(), 5, 0.3,0.3,0.3,0.01);
            Component line = Component.text("━━━━━━━━━", NamedTextColor.WHITE);
            t.sendActionBar(line);
        }, 0, 1);
        slamTask.put(tid, trail);

        Bukkit.getScheduler().runTaskLater(plugin, () -> {
            if (!t.isOnline()) return;
            t.setVelocity(new Vector(0, -3.0, 0));
        }, (long)(up * 0.4));

        Bukkit.getScheduler().runTaskTimer(plugin, task -> {
            if (!t.isOnline()) { task.cancel(); slamTask.remove(tid); return; }
            if (t.isOnGround()) {
                task.cancel();
                BukkitTask tr = slamTask.remove(tid);
                if (tr != null) tr.cancel();
                Player casterRef = Bukkit.getPlayer(a.getUniqueId());
                hurt(t, cd("slam.damage-hearts",2.5), casterRef != null ? casterRef : a, "puff.slam");
                t.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS, ticks("slam.slow-seconds",4.0), 3));
                t.getWorld().spawnParticle(Particle.POOF, t.getLocation(), 20, 1,0.5,1,0.05);
                t.getWorld().playSound(t.getLocation(), Sound.ENTITY_GENERIC_EXPLODE, 1,0.8f);
            }
        }, (long)(up * 0.2), 1);

        startCd(a, 1);
        bar(a, "Puff Slam!", NamedTextColor.AQUA);
    }

    // ======== Tornado
    private void tornado(Player p) {
        Location start = p.getLocation().clone();
        Vector dir = p.getLocation().getDirection().setY(0).normalize().multiply(0.4);
        final Location[] pos = {start.clone()};
        final double[] height = {1.0};
        final Set<UUID> caught = new HashSet<>();
        final long[] begun = {now()};
        final int[] age = {0};

        BukkitTask task = Bukkit.getScheduler().runTaskTimer(plugin, t -> {
            age[0]++;
            pos[0].add(dir);
            height[0] = Math.min(8.0, 1.0 + age[0] * 0.08);
            Location center = pos[0].clone();

            for (double y = 0; y <= height[0]; y += 0.5) {
                double angle = (age[0] * 25 + y * 60) * Math.PI / 180;
                double r = 1.0 + y * 0.15;
                Location l = center.clone().add(Math.cos(angle)*r, y, Math.sin(angle)*r);
                p.getWorld().spawnParticle(Particle.POOF, l, 1, 0,0,0,0);
            }

            if (!p.isOnline()) { t.cancel(); tornadoTask.remove(p.getUniqueId()); return; }
            if (caught.isEmpty() && now() - begun[0] > 3000) { t.cancel(); tornadoTask.remove(p.getUniqueId()); return; }

            for (Player target : new ArrayList<>(p.getWorld().getNearbyPlayers(center, 2.0, height[0]/2.0, 2.0))) {
                if (target.equals(p) || caught.contains(target.getUniqueId())) continue;
                caught.add(target.getUniqueId());
                trapInTornado(target, p);
            }

            if (age[0] > 200) { t.cancel(); tornadoTask.remove(p.getUniqueId()); }
        }, 0, 1);
        tornadoTask.put(p.getUniqueId(), task);
        startCd(p, 2);
        bar(p, "Tornado!", NamedTextColor.AQUA);
    }

    private void trapInTornado(Player t, Player caster) {
        int dur = ticks("tornado.trap-seconds", 6.0);
        status.stun(t, (long)(cd("tornado.trap-seconds",6.0)*1000));
        t.sendActionBar(Component.text("Trapped in a tornado!", NamedTextColor.RED));

        BukkitTask box = Bukkit.getScheduler().runTaskTimer(plugin, task -> {
            if (!t.isOnline()) { task.cancel(); return; }
            Location center = t.getLocation().add(0,1,0);
            for (double a = 0; a < 360; a += 30) {
                double rad = a * Math.PI / 180;
                t.getWorld().spawnParticle(Particle.POOF, center.clone().add(Math.cos(rad)*1.5,0,Math.sin(rad)*1.5),1,0,0,0,0);
                t.getWorld().spawnParticle(Particle.POOF, center.clone().add(Math.cos(rad)*1.5,1,Math.sin(rad)*1.5),1,0,0,0,0);
            }
        }, 0, 2);

        long trapEnd = now() + (long)(cd("tornado.trap-seconds",6.0)*1000);
        long[] lastDmg = {now()};
        Bukkit.getScheduler().runTaskTimer(plugin, task -> {
            if (!t.isOnline() || now() >= trapEnd) {
                task.cancel(); box.cancel();
                return;
            }
            if (now() - lastDmg[0] >= 2000) {
                lastDmg[0] = now();
                Player c = Bukkit.getPlayer(caster.getUniqueId());
                if (c != null) hurt(t, cd("tornado.damage-hearts",1.5), c, "puff.tornado");
            }
            t.setVelocity(new Vector(0,0.1,0));
        }, 0, 2);
    }

    // ======== Air Lock
    private void airLock(Player p) {
        Player nearest = nearest(p, cd("airlock.radius",8.0));
        if (nearest == null) { bar(p, "No player in range.", NamedTextColor.GRAY); return; }
        long until = now() + ms("airlock.duration-seconds", 20.0);
        airLockUntil.put(nearest.getUniqueId(), until);
        nearest.sendMessage(Component.text("You have been Air Locked!", NamedTextColor.RED));
        bar(p, "Air Lock on " + nearest.getName() + "!", NamedTextColor.AQUA);
        startCd(p, 3);
    }

    @EventHandler(priority = EventPriority.LOWEST)
    public void onAirLockUse(PlayerInteractEvent e) {
        Player p = e.getPlayer();
        Long until = airLockUntil.get(p.getUniqueId());
        if (until == null || until <= now()) { airLockUntil.remove(p.getUniqueId()); return; }
        Action a = e.getAction();
        if (a != Action.RIGHT_CLICK_AIR && a != Action.RIGHT_CLICK_BLOCK) return;
        org.bukkit.inventory.ItemStack item = e.getItem();
        if (item == null) return;
        Material m = item.getType();
        if (m == Material.ENDER_PEARL || m == Material.WIND_CHARGE || m == Material.COBWEB
                || m.name().endsWith("_POTION")) {
            e.setCancelled(true);
            bar(p, "Your utilities are locked!", NamedTextColor.RED);
        }
    }

    // ======== Updraft
    private void updraft(Player p) {
        p.setVelocity(new Vector(0, 1.8, 0));
        p.getWorld().playSound(p.getLocation(), Sound.ENTITY_PHANTOM_FLAP, 1, 1.5f);
        int rise = ticks("updraft.rise-seconds",1.2);
        Bukkit.getScheduler().runTaskLater(plugin, () -> {
            if (!p.isOnline()) return;
            p.setVelocity(new Vector(0,-3.5,0));
            final boolean[] shockFired = {false};
        Bukkit.getScheduler().runTaskTimer(plugin, task -> {
                if (!p.isOnline()) { task.cancel(); return; }
                if (!shockFired[0] && p.isOnGround()) {
                    shockFired[0] = true;
                    task.cancel();
                    shockwave(p);
                }
            },1,1);
        }, rise);
        startCd(p, 4);
        bar(p, "Updraft!", NamedTextColor.AQUA);
    }

    private void shockwave(Player p) {
        double r = cd("updraft.radius",5.0) * plugin.energy().reachFactor(p);
        for (Player t : new ArrayList<>(p.getWorld().getNearbyPlayers(p.getLocation(), r))) {
            if (t.equals(p)) continue;
            hurt(t, cd("updraft.damage-hearts",2.0), p, "puff.updraft");
            status.stun(t, (long)(cd("updraft.stun-seconds",3.0)*1000));
            Vector away = t.getLocation().toVector().subtract(p.getLocation().toVector()).setY(0.3).normalize().multiply(1.5);
            t.setVelocity(away);
        }
        p.getWorld().spawnParticle(Particle.POOF, p.getLocation(), 30, r/2,0.3,r/2,0.05);
        p.getWorld().playSound(p.getLocation(), Sound.ENTITY_GENERIC_EXPLODE,1,0.9f);
    }

    private Player nearest(Player p, double r) {
        Player best = null; double bd = Double.MAX_VALUE;
        for (Player o : p.getWorld().getNearbyPlayers(p.getLocation(), r)) {
            if (o.equals(p) || o.isDead() || o.getGameMode()==GameMode.SPECTATOR) continue;
            double d = o.getLocation().distanceSquared(p.getLocation());
            if (d < bd) { bd = d; best = o; }
        }
        return best;
    }

    // Wind block helper
    private void windBlock(Player t, long ms) { windBlockUntil.merge(t.getUniqueId(), now()+ms, Math::max); }

    @EventHandler(priority = EventPriority.LOWEST)
    public void onWindCharge(PlayerInteractEvent e) {
        Player p = e.getPlayer();
        Long u = windBlockUntil.get(p.getUniqueId());
        if (u == null || u <= now()) { windBlockUntil.remove(p.getUniqueId()); return; }
        if (e.getItem() != null && e.getItem().getType() == Material.WIND_CHARGE) {
            e.setCancelled(true);
            bar(p, "Wind charges disabled!", NamedTextColor.RED);
        }
    }

    // ======== Flight allow (double jump)
    @EventHandler
    public void onJoinFlight(PlayerJoinEvent e) {
        Player p = e.getPlayer();
        if (hasPuff(p) && gems.usable(p) && p.getGameMode() != GameMode.CREATIVE && p.getGameMode() != GameMode.SPECTATOR)
            p.setAllowFlight(true);
    }

    // tick
    private void tick() {
        // allow flight while holding puff
        for (Player p : Bukkit.getOnlinePlayers()) {
            if (p.getGameMode() == GameMode.CREATIVE || p.getGameMode() == GameMode.SPECTATOR) continue;
            boolean puff = hasPuff(p) && gems.usable(p) && !gems.isRolling(p);
            if (puff && !p.getAllowFlight()) p.setAllowFlight(true);
            else if (!puff && p.getAllowFlight() && !p.isFlying()) p.setAllowFlight(false);
            boolean onGround = p.isOnGround();
            if (onGround) {
                jumping.remove(p.getUniqueId());
                stopTrail(p);
            } else if (p.getVelocity().getY() > 0.3 && !jumping.contains(p.getUniqueId())) {
                // Player just jumped (upward velocity while airborne)
                jumping.add(p.getUniqueId());
                lastJumpTime.put(p.getUniqueId(), now());
            }

            // speed alternating
            if (puff) {
                long t = now() / 1000;
                PotionEffectType type = (t % 2 == 0) ? PotionEffectType.SPEED : PotionEffectType.SPEED;
                int amp = (t % 2 == 0) ? 0 : 1; // Speed 1 then Speed 2
                PotionEffect cur = p.getPotionEffect(PotionEffectType.SPEED);
                if (cur == null || cur.getAmplifier() != amp || cur.getDuration() < 15)
                    p.addPotionEffect(new PotionEffect(PotionEffectType.SPEED, 25, amp, true, false, true));
            }

            // sneak enchant check
            Long ss = sneakStart.get(p.getUniqueId());
            if (ss != null && now() - ss >= ms("feather-falling.sneak-seconds",1.0)) {
                sneakStart.remove(p.getUniqueId());
                tryEnchantBoots(p);
            }
        }
        airLockUntil.entrySet().removeIf(en -> en.getValue() <= now());
    }

    private void tryEnchantBoots(Player p) {
        if (!hasPuff(p) || !gems.usable(p)) return;
        UUID id = p.getUniqueId();
        if (cd.remainingMs(id, "puff_sharp") > 0) return;
        org.bukkit.inventory.ItemStack boots = p.getInventory().getItemInOffHand();
        if (boots == null || !boots.getType().name().endsWith("_BOOTS")) { bar(p,"Hold boots in offhand.",NamedTextColor.GRAY); return; }
        int lvl = plugin.getConfig().getInt("puff.feather-falling.level",4);
        if (boots.getItemMeta().getEnchantLevel(org.bukkit.enchantments.Enchantment.FEATHER_FALLING) >= lvl) { bar(p,"Boots already have Feather Falling "+lvl+".",NamedTextColor.GRAY); return; }
        org.bukkit.inventory.meta.ItemMeta meta = boots.getItemMeta();
        meta.addEnchant(org.bukkit.enchantments.Enchantment.FEATHER_FALLING, lvl, true);
        boots.setItemMeta(meta);
        p.getInventory().setItemInOffHand(boots);
        cd.start(id,"puff_sharp",ms("feather-falling.cooldown-seconds",180.0),"Feather Falling");
        bar(p,"Boots enchanted with Feather Falling "+lvl+"!",NamedTextColor.AQUA);
        p.playSound(p.getLocation(),Sound.BLOCK_ENCHANTMENT_TABLE_USE,1,1);
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        UUID id = e.getPlayer().getUniqueId();
        jumping.remove(id); lastJumpTime.remove(id); sneakStart.remove(id);
        stopTrail(e.getPlayer()); awaiting.remove(id);
        airLockUntil.remove(id); windBlockUntil.remove(id); upwindHits.remove(id);
    }

    @EventHandler
    public void onDeath(PlayerDeathEvent e) {
        UUID id = e.getEntity().getUniqueId();
        jumping.remove(id); sneakStart.remove(id); awaiting.remove(id);
        stopTrail(e.getEntity()); airLockUntil.remove(id);
    }
}
