package com.example.gems;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/** Sneak + right-click cycles the selected ability. Right-click uses it. */
public class AbilityListener implements Listener {

    private final GemsPlugin plugin;
    private final Map<UUID, Long> lastUse = new HashMap<>();

    public AbilityListener(GemsPlugin plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onInteract(PlayerInteractEvent e) {
        if (e.getHand() != EquipmentSlot.HAND) return;
        Action action = e.getAction();
        if (action != Action.RIGHT_CLICK_AIR && action != Action.RIGHT_CLICK_BLOCK) return;

        GemManager gems = plugin.gems();
        ItemStack item = e.getItem();
        GemType type = gems.getGem(item);
        if (type == null) return;

        Player p = e.getPlayer();
        if (gems.isRolling(p)) {
            e.setCancelled(true); // gems can't be used during the roll
            return;
        }
        // Let people still use doors, chests, buttons etc. when they aren't sneaking.
        if (action == Action.RIGHT_CLICK_BLOCK && !p.isSneaking() && e.getClickedBlock() != null
                && e.getClickedBlock().getType().isInteractable()) {
            return;
        }

        e.setCancelled(true);
        if (!gems.isStarted()) return;

        // Some clients (Bedrock) can send a click twice; ignore the duplicate.
        long now = System.currentTimeMillis();
        Long prev = lastUse.get(p.getUniqueId());
        if (prev != null && now - prev < 150L) return;
        lastUse.put(p.getUniqueId(), now);

        List<String> names = Abilities.names(type);
        if (names.isEmpty()) {
            p.sendActionBar(Component.text("This gem has no abilities yet.", NamedTextColor.GRAY));
            return;
        }

        int sel = gems.getSelected(item, names.size());
        if (p.isSneaking()) {
            sel = (sel + 1) % names.size();
            ItemStack inHand = p.getInventory().getItemInMainHand();
            gems.setSelected(inHand, type, sel, p);
            p.getInventory().setItemInMainHand(inHand);
            p.sendActionBar(Component.text("Selected: ", NamedTextColor.GRAY)
                    .append(Component.text(names.get(sel), type.color())));
            p.playSound(p.getLocation(), Sound.UI_BUTTON_CLICK, 0.6f, 1.2f);
        } else if (type == GemType.STRENGTH) {
            plugin.strength().activate(p, sel);
        } else if (type == GemType.PUFF) {
            plugin.puff().activate(p, sel);
        } else if (type == GemType.SPEED) {
            plugin.speed().activate(p, sel);
        }
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        lastUse.remove(e.getPlayer().getUniqueId());
    }
}
