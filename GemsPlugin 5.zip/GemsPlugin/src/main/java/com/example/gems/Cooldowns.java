package com.example.gems;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

public class Cooldowns {

    private final Map<UUID, Map<String, Long>> ends = new HashMap<>();
    private final Map<UUID, Map<String, String>> labels = new HashMap<>(); // key -> display name
    private final Set<String> notifyKeys = new HashSet<>();

    public long remainingMs(UUID id, String key) {
        Map<String, Long> m = ends.get(id);
        if (m == null) return 0L;
        Long end = m.get(key);
        if (end == null) return 0L;
        long left = end - System.currentTimeMillis();
        if (left <= 0L) {
            m.remove(key);
            return 0L;
        }
        return left;
    }

    /**
     * Starts a cooldown. If label is provided the player gets a chat notification when it expires.
     */
    public void start(UUID id, String key, long ms) {
        start(id, key, ms, null);
    }

    public void start(UUID id, String key, long ms, String label) {
        ends.computeIfAbsent(id, k -> new HashMap<>()).put(key, System.currentTimeMillis() + ms);
        if (label != null) {
            labels.computeIfAbsent(id, k -> new HashMap<>()).put(key, label);
            notifyKeys.add(key);
        }
    }

    /** Call every second to fire ready notifications. */
    public void tick() {
        long now = System.currentTimeMillis();
        for (UUID id : new HashSet<>(labels.keySet())) {
            Map<String, String> lm = labels.get(id);
            if (lm == null) continue;
            Map<String, Long> em = ends.get(id);
            for (String key : new HashSet<>(lm.keySet())) {
                boolean ended = em == null || !em.containsKey(key) || em.get(key) <= now;
                if (ended) {
                    String name = lm.remove(key);
                    Player p = Bukkit.getPlayer(id);
                    if (p != null && p.isOnline()) {
                        p.sendMessage(Component.text(name + " is ready!", NamedTextColor.GREEN));
                    }
                }
            }
            if (lm.isEmpty()) labels.remove(id);
        }
    }

    public void clearAll() {
        ends.clear();
        labels.clear();
    }

    public void prune(UUID id) {
        long now = System.currentTimeMillis();
        Map<String, Long> m = ends.get(id);
        if (m != null) {
            m.values().removeIf(t -> t <= now);
            if (m.isEmpty()) ends.remove(id);
        }
        labels.remove(id);
    }

    public static String format(long ms) {
        long s = (ms + 999) / 1000;
        long m = s / 60;
        return m > 0 ? m + "m " + (s % 60) + "s" : s + "s";
    }
}
