package com.example.gems;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Material;
import org.bukkit.entity.Item;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.inventory.ClickType;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.inventory.InventoryPickupItemEvent;
import org.bukkit.event.inventory.InventoryType;
import org.bukkit.event.inventory.PrepareItemCraftEvent;
import org.bukkit.event.player.PlayerArmorStandManipulateEvent;
import org.bukkit.event.player.PlayerDropItemEvent;
import org.bukkit.event.player.PlayerInteractEntityEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;

import java.util.Iterator;

/** Keeps gems from leaving a player's inventory unless a Gem Trader is used. */
public class GemProtectionListener implements Listener {

    private final GemsPlugin plugin;

    public GemProtectionListener(GemsPlugin plugin) {
        this.plugin = plugin;
    }

    private boolean isGem(ItemStack item) {
        return plugin.gems().isGem(item);
    }

    private static boolean isBundle(ItemStack item) {
        return item != null && item.getType().name().endsWith("BUNDLE");
    }

    // Dropping a gem requires (and consumes) a Gem Trader. A dropped gem never despawns or burns.
    @EventHandler(ignoreCancelled = true)
    public void onDrop(PlayerDropItemEvent e) {
        Item entity = e.getItemDrop();
        if (!isGem(entity.getItemStack())) return;
        Player p = e.getPlayer();
        if (plugin.gems().consumeTrader(p)) {
            entity.setUnlimitedLifetime(true);
            entity.setInvulnerable(true);
            p.sendMessage(Component.text("Gem Trader used. Your gem was dropped.", NamedTextColor.GOLD));
        } else {
            e.setCancelled(true);
            p.sendMessage(Component.text("You need a Gem Trader to drop a gem.", NamedTextColor.RED));
        }
    }

    // Hoppers can't suck dropped gems up.
    @EventHandler(ignoreCancelled = true)
    public void onHopperPickup(InventoryPickupItemEvent e) {
        if (isGem(e.getItem().getItemStack())) e.setCancelled(true);
    }

    // Stop gems being moved into chests, ender chests, villager trades, crafting grids, bundles, etc.
    @EventHandler(ignoreCancelled = true)
    public void onClick(InventoryClickEvent e) {
        if (!(e.getWhoClicked() instanceof Player p)) return;

        ItemStack cursor = e.getCursor();
        ItemStack current = e.getCurrentItem();

        // Bundles would let a gem slip into a container.
        if ((isGem(cursor) && isBundle(current)) || (isBundle(cursor) && isGem(current))) {
            deny(e, p);
            return;
        }

        Inventory clicked = e.getClickedInventory();
        if (clicked == null) return;
        Inventory top = e.getView().getTopInventory();
        ClickType click = e.getClick();

        if (clicked.equals(top)) {
            boolean bad = isGem(cursor)
                    || (click == ClickType.NUMBER_KEY && e.getHotbarButton() >= 0
                        && isGem(p.getInventory().getItem(e.getHotbarButton())))
                    || (click == ClickType.SWAP_OFFHAND && isGem(p.getInventory().getItemInOffHand()));
            if (bad) deny(e, p);
        } else if (click.isShiftClick() && isGem(current) && top.getType() != InventoryType.CRAFTING) {
            // Shift-clicking inside your own inventory screen is fine; into any other screen is not.
            deny(e, p);
        }
    }

    private void deny(InventoryClickEvent e, Player p) {
        e.setCancelled(true);
        p.sendMessage(Component.text("Gems can't be stored. Use a Gem Trader to trade them.", NamedTextColor.RED));
    }

    @EventHandler(ignoreCancelled = true)
    public void onDrag(InventoryDragEvent e) {
        if (!isGem(e.getOldCursor())) return;
        int topSize = e.getView().getTopInventory().getSize();
        for (int slot : e.getRawSlots()) {
            if (slot < topSize) {
                e.setCancelled(true);
                return;
            }
        }
    }

    // A gem can't be handed to any entity: item frames, allays, wolves (bones), villagers (emeralds)...
    @EventHandler(ignoreCancelled = true)
    public void onInteractEntity(PlayerInteractEntityEvent e) {
        if (isGem(e.getPlayer().getInventory().getItem(e.getHand()))) e.setCancelled(true);
    }

    @EventHandler(ignoreCancelled = true)
    public void onArmorStand(PlayerArmorStandManipulateEvent e) {
        if (isGem(e.getPlayerItem())) e.setCancelled(true);
    }

    // Decorated pots accept any item.
    @EventHandler(ignoreCancelled = true)
    public void onInteractBlock(PlayerInteractEvent e) {
        if (e.getAction() != Action.RIGHT_CLICK_BLOCK || e.getClickedBlock() == null) return;
        if (e.getClickedBlock().getType() == Material.DECORATED_POT && isGem(e.getItem())) {
            e.setCancelled(true);
        }
    }

    // Some gem materials are blocks (nether wart, packed ice).
    @EventHandler(ignoreCancelled = true)
    public void onPlace(BlockPlaceEvent e) {
        if (isGem(e.getItemInHand())) e.setCancelled(true);
    }

    // Gems can't be used as crafting ingredients.
    @EventHandler
    public void onPrepareCraft(PrepareItemCraftEvent e) {
        for (ItemStack it : e.getInventory().getMatrix()) {
            if (isGem(it)) {
                e.getInventory().setResult(null);
                return;
            }
        }
    }

    // Gems are kept on death. The server hands kept items back on respawn, so they can't be lost
    // even if the player disconnects while dead.
    @EventHandler
    public void onDeath(PlayerDeathEvent e) {
        Iterator<ItemStack> it = e.getDrops().iterator();
        while (it.hasNext()) {
            ItemStack drop = it.next();
            if (isGem(drop)) {
                e.getItemsToKeep().add(drop);
                it.remove();
            }
        }
    }
}
