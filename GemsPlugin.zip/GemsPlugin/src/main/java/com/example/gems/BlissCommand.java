package com.example.gems;

import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.List;

public class BlissCommand implements CommandExecutor, TabCompleter {

    private static final String USAGE = "§eUsage: /bliss <start|stop|trader>";

    private final GemsPlugin plugin;

    public BlissCommand(GemsPlugin plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        GemManager gems = plugin.gems();

        if (args.length == 0) {
            sender.sendMessage(USAGE);
            return true;
        }

        switch (args[0].toLowerCase()) {
            case "start" -> {
                if (gems.isStarted()) {
                    sender.sendMessage("§cGems are already started.");
                    return true;
                }
                gems.setStarted(true);
                Bukkit.broadcastMessage("§aGems have started! Gems will be handed out shortly.");
                for (Player p : Bukkit.getOnlinePlayers()) {
                    gems.scheduleGive(p);
                }
            }
            case "stop" -> {
                if (!gems.isStarted()) {
                    sender.sendMessage("§cGems are not running.");
                    return true;
                }
                gems.setStarted(false);
                sender.sendMessage("§eGems stopped. Pending gem handouts are cancelled.");
            }
            case "trader" -> {
                if (args.length < 2) {
                    sender.sendMessage("§eUsage: /bliss trader <player>");
                    return true;
                }
                Player target = Bukkit.getPlayerExact(args[1]);
                if (target == null) {
                    sender.sendMessage("§cPlayer not found.");
                    return true;
                }
                target.getInventory().addItem(gems.createTrader())
                        .values().forEach(i -> target.getWorld().dropItemNaturally(target.getLocation(), i));
                sender.sendMessage("§aGave a Gem Trader to " + target.getName() + ".");
            }
            default -> sender.sendMessage(USAGE);
        }
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command cmd, String alias, String[] args) {
        List<String> out = new ArrayList<>();
        if (args.length == 1) {
            for (String s : List.of("start", "stop", "trader")) {
                if (s.startsWith(args[0].toLowerCase())) out.add(s);
            }
        } else if (args.length == 2 && args[0].equalsIgnoreCase("trader")) {
            for (Player p : Bukkit.getOnlinePlayers()) {
                if (p.getName().toLowerCase().startsWith(args[1].toLowerCase())) out.add(p.getName());
            }
        }
        return out;
    }
}
