package com.example.gems;

import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;

public class JoinListener implements Listener {

    private final GemsPlugin plugin;

    public JoinListener(GemsPlugin plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent event) {
        // Unlock the Gem Trader recipe in the recipe book.
        event.getPlayer().discoverRecipe(plugin.traderRecipeKey());

        // Does nothing until /bliss start has been run.
        plugin.gems().scheduleGive(event.getPlayer());
    }
}
