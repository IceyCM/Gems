package com.example.gems;

import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerRespawnEvent;

public class JoinListener implements Listener {

    private final GemsPlugin plugin;

    public JoinListener(GemsPlugin plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent event) {
        Player p = event.getPlayer();

        // Remove gems left over from before a /bliss reset (this is how offline players get cleaned up).
        plugin.gems().purgeStale(p);
        plugin.sweepBundles(p);

        // Unlock the Gem Trader recipe in the recipe book.
        p.discoverRecipe(plugin.traderRecipeKey());

        // Does nothing until /bliss start has been run.
        plugin.gems().scheduleGive(p);
    }

    // Leaving mid-roll still gives the gem they were rolling towards.
    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        plugin.gems().finishNow(event.getPlayer());
    }

    // Kept-on-death gems come back at respawn, so check again then.
    @EventHandler
    public void onRespawn(PlayerRespawnEvent event) {
        Player p = event.getPlayer();
        Bukkit.getScheduler().runTask(plugin, () -> {
            if (p.isOnline()) plugin.gems().purgeStale(p);
        });
    }
}
