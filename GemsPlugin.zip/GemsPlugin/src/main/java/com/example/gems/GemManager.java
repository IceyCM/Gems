package com.example.gems;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import org.bukkit.Bukkit;
import net.kyori.adventure.title.Title;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.Sound;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;

import java.io.File;
import java.time.Duration;
import java.util.ArrayList;
import java.util.EnumSet;
import java.util.HashSet;
import java.util.Set;
import java.io.IOException;
import java.util.List;
import java.util.UUID;
import java.util.concurrent.ThreadLocalRandom;

public class GemManager {

    /** Every material a gem can be. Checked first so ordinary items never touch item meta. */
    private static final EnumSet<Material> GEM_MATERIALS = EnumSet.noneOf(Material.class);
    static {
        for (GemType t : GemType.values()) GEM_MATERIALS.add(t.material());
    }

    private final GemsPlugin plugin;
    private final NamespacedKey gemKey;
    private final NamespacedKey traderKey;
    private final Set<UUID> rolling = new HashSet<>();
    private final Set<UUID> pending = new HashSet<>();
    private final File dataFile;
    private final YamlConfiguration data;

    public GemManager(GemsPlugin plugin) {
        this.plugin = plugin;
        this.gemKey = new NamespacedKey(plugin, "gem");
        this.traderKey = new NamespacedKey(plugin, "trader");
        this.dataFile = new File(plugin.getDataFolder(), "data.yml");
        this.data = YamlConfiguration.loadConfiguration(dataFile);
    }

    public ItemStack createGem(GemType type) {
        ItemStack item = new ItemStack(type.material());
        ItemMeta meta = item.getItemMeta();
        meta.displayName(Component.text(type.displayName() + " Gem", type.color())
                .decoration(TextDecoration.ITALIC, false));
        meta.lore(List.of(Component.text("Selected: none yet", NamedTextColor.GRAY)
                .decoration(TextDecoration.ITALIC, false)));
        meta.setEnchantmentGlintOverride(true);
        meta.setMaxStackSize(1);
        meta.getPersistentDataContainer().set(gemKey, PersistentDataType.STRING, type.name());
        item.setItemMeta(meta);
        return item;
    }

    public boolean isGem(ItemStack item) {
        return getGem(item) != null;
    }

    public ItemStack createTrader() {
        ItemStack item = new ItemStack(Material.NETHER_STAR);
        ItemMeta meta = item.getItemMeta();
        meta.displayName(Component.text("Gem Trader", NamedTextColor.GOLD)
                .decoration(TextDecoration.ITALIC, false));
        meta.lore(List.of(Component.text("Right-click to roll a new gem.", NamedTextColor.GRAY)
                        .decoration(TextDecoration.ITALIC, false),
                Component.text("Also needed to drop a gem. Consumed on use.", NamedTextColor.GRAY)
                        .decoration(TextDecoration.ITALIC, false)));
        meta.setEnchantmentGlintOverride(true);
        meta.getPersistentDataContainer().set(traderKey, PersistentDataType.BYTE, (byte) 1);
        item.setItemMeta(meta);
        return item;
    }

    public boolean isTrader(ItemStack item) {
        return item != null && item.getType() == Material.NETHER_STAR && item.hasItemMeta()
                && item.getItemMeta().getPersistentDataContainer().has(traderKey, PersistentDataType.BYTE);
    }

    /** Removes one Gem Trader from the player's inventory. Returns false if they have none. */
    public boolean consumeTrader(Player player) {
        ItemStack[] contents = player.getInventory().getContents();
        for (int i = 0; i < contents.length; i++) {
            ItemStack it = contents[i];
            if (isTrader(it)) {
                if (it.getAmount() <= 1) {
                    player.getInventory().setItem(i, null);
                } else {
                    it.setAmount(it.getAmount() - 1);
                }
                return true;
            }
        }
        return false;
    }

    /** Returns the gem type of an item, or null if it isn't a gem. */
    public GemType getGem(ItemStack item) {
        if (item == null || !GEM_MATERIALS.contains(item.getType()) || !item.hasItemMeta()) return null;
        String id = item.getItemMeta().getPersistentDataContainer()
                .get(gemKey, PersistentDataType.STRING);
        if (id == null) return null;
        try {
            return GemType.valueOf(id);
        } catch (IllegalArgumentException e) {
            return null;
        }
    }

    public boolean isStarted() {
        return data.getBoolean("started", false);
    }

    public void setStarted(boolean started) {
        data.set("started", started);
        save();
    }

    /** Gives the player a gem after the configured delay (not instantly). */
    public void scheduleGive(Player player) {
        UUID uuid = player.getUniqueId();
        if (!isStarted() || hasReceived(uuid) || rolling.contains(uuid) || !pending.add(uuid)) return;
        long delayTicks = Math.max(0L, plugin.getConfig().getLong("assignment.delay-seconds", 60)) * 20L;
        Bukkit.getScheduler().runTaskLater(plugin, () -> {
            pending.remove(uuid);
            Player p = Bukkit.getPlayer(uuid);
            if (p != null && p.isOnline() && isStarted()) {
                giveRandomGem(p);
            }
        }, delayTicks);
    }

    public boolean hasReceived(UUID uuid) {
        return data.contains("received." + uuid);
    }

    /** First-time handout: roll and receive a random gem. */
    public void giveRandomGem(Player player) {
        startRoll(player, false);
    }

    /** Gem Trader use: roll to a new random gem that replaces the one they hold. */
    public void startTrade(Player player) {
        if (!isStarted()) {
            player.sendMessage(Component.text("Gems haven't started yet.", NamedTextColor.RED));
            return;
        }
        if (rolling.contains(player.getUniqueId())) return;
        if (findGemSlot(player) < 0) {
            player.sendMessage(Component.text("You don't have a gem to trade.", NamedTextColor.RED));
            return;
        }
        startRoll(player, true);
    }

    private int findGemSlot(Player p) {
        ItemStack[] contents = p.getInventory().getContents();
        for (int i = 0; i < contents.length; i++) {
            if (isGem(contents[i])) return i;
        }
        return -1;
    }

    /**
     * Casino-style animation through every gem that slows down and lands on the chosen one.
     * Uses titles, sounds and particles only, so it works for Java and Bedrock (Geyser) players.
     */
    private void startRoll(Player player, boolean trade) {
        UUID uuid = player.getUniqueId();
        if (!trade && hasReceived(uuid)) return;
        if (!rolling.add(uuid)) return;

        GemType[] all = GemType.values();
        List<GemType> pool = new ArrayList<>(List.of(all));
        if (trade) {
            pool.remove(getGem(player.getInventory().getItem(findGemSlot(player)))); // always a new gem
        }
        int target = pool.get(ThreadLocalRandom.current().nextInt(pool.size())).ordinal();

        int frames = 28;
        // Pick the start so that the final frame lands exactly on the chosen gem.
        int start = Math.floorMod(target - (frames - 1), all.length);
        playFrame(uuid, all, start, 0, frames, trade);
    }

    private void playFrame(UUID uuid, GemType[] all, int start, int i, int frames, boolean trade) {
        Player p = Bukkit.getPlayer(uuid);
        // If they leave or gems get stopped mid-roll, cancel with nothing changed.
        if (p == null || !p.isOnline() || !isStarted()) {
            rolling.remove(uuid);
            return;
        }

        if (p.isDead()) {
            Bukkit.getScheduler().runTaskLater(plugin, () -> playFrame(uuid, all, start, i, frames, trade), 20L);
            return;
        }

        GemType shown = all[(start + i) % all.length];

        if (i == frames - 1) {
            rolling.remove(uuid);
            if (trade) {
                completeTrade(p, shown);
            } else {
                award(p, shown);
            }
            return;
        }

        p.showTitle(Title.title(
                Component.text(shown.displayName(), shown.color()),
                Component.text("Rolling...", NamedTextColor.GRAY),
                Title.Times.times(Duration.ZERO, Duration.ofMillis(400), Duration.ZERO)));
        // Ding with rising pitch, plus particles that match the gem currently shown.
        p.playSound(p.getLocation(), Sound.BLOCK_NOTE_BLOCK_BELL, 1.0f, 0.7f + i * 0.045f);
        burst(p, shown, 15);

        // Fast at first, then slows down like a slot machine.
        long delay = i < 14 ? 2 : i < 20 ? 3 : i < 24 ? 5 : 8;
        Bukkit.getScheduler().runTaskLater(plugin, () -> playFrame(uuid, all, start, i + 1, frames, trade), delay);
    }

    /** Swaps the player's current gem for the new one, consuming one Gem Trader. */
    private void completeTrade(Player p, GemType type) {
        int slot = findGemSlot(p);
        // The trader is only used up now, so quitting or dropping it mid-roll can't lose or dupe anything.
        if (slot < 0 || !consumeTrader(p)) {
            p.sendMessage(Component.text("Trade cancelled.", NamedTextColor.RED));
            return;
        }
        p.getInventory().setItem(slot, null);
        award(p, type);
    }

    private void burst(Player p, GemType type, int count) {
        p.getWorld().spawnParticle(type.particle(), p.getLocation().add(0, 1.0, 0),
                count, 0.6, 0.8, 0.6, 0.02);
    }

    private void award(Player player, GemType type) {
        var leftover = player.getInventory().addItem(createGem(type));
        leftover.values().forEach(i -> player.getWorld().dropItemNaturally(player.getLocation(), i));

        data.set("received." + player.getUniqueId(), type.name());
        save();

        player.showTitle(Title.title(
                Component.text(type.displayName() + " Gem", type.color()),
                Component.text("is yours!", NamedTextColor.WHITE),
                Title.Times.times(Duration.ZERO, Duration.ofSeconds(3), Duration.ofSeconds(1))));
        burst(player, type, 60);
        player.playSound(player.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 1.0f, 1.0f);
        player.playSound(player.getLocation(), Sound.UI_TOAST_CHALLENGE_COMPLETE, 1.0f, 1.0f);

        String msg = plugin.getConfig().getString("assignment.message", "&aYou received the &f%gem% &agem!")
                .replace("%gem%", type.displayName());
        player.sendMessage(LegacyComponentSerializer.legacyAmpersand().deserialize(msg));
    }

    private void save() {
        try {
            data.save(dataFile);
        } catch (IOException e) {
            plugin.getLogger().severe("Could not save data.yml: " + e.getMessage());
        }
    }
}
