package com.example.gems;

import java.util.List;

/** The selectable abilities of each gem, in cycling order. */
public final class Abilities {

    private static final List<String> STRENGTH = List.of("Chad Strength", "Fractured", "Super Smash", "Frailer");

    private Abilities() {}

    public static List<String> names(GemType type) {
        return type == GemType.STRENGTH ? STRENGTH : List.of();
    }
}
