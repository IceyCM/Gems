package com.example.gems;

import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ShapelessRecipe;
import org.bukkit.plugin.java.JavaPlugin;

public class GemsPlugin extends JavaPlugin {

    private GemManager gemManager;
    private NamespacedKey traderRecipeKey;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        gemManager = new GemManager(this);
        registerTraderRecipe();
        getServer().getPluginManager().registerEvents(new JoinListener(this), this);
        getServer().getPluginManager().registerEvents(new GemProtectionListener(this), this);
        getServer().getPluginManager().registerEvents(new TraderListener(this), this);
        BlissCommand bliss = new BlissCommand(this);
        getCommand("bliss").setExecutor(bliss);
        getCommand("bliss").setTabCompleter(bliss);

        // Show the recipe in the recipe book for anyone already online (e.g. after /reload).
        for (Player p : Bukkit.getOnlinePlayers()) {
            p.discoverRecipe(traderRecipeKey);
        }
        getLogger().info("Gems enabled. Use /bliss start to begin.");
    }

    @Override
    public void onDisable() {
        if (traderRecipeKey != null) {
            Bukkit.removeRecipe(traderRecipeKey);
        }
    }

    /** Gem Trader: 2 Netherite Ingots, 2 Nautilus Shells, 1 Enchanted Golden Apple, 4 Totems of Undying. */
    private void registerTraderRecipe() {
        traderRecipeKey = new NamespacedKey(this, "gem_trader");
        ShapelessRecipe recipe = new ShapelessRecipe(traderRecipeKey, gemManager.createTrader());
        recipe.addIngredient(2, Material.NETHERITE_INGOT);
        recipe.addIngredient(2, Material.NAUTILUS_SHELL);
        recipe.addIngredient(1, Material.ENCHANTED_GOLDEN_APPLE);
        recipe.addIngredient(4, Material.TOTEM_OF_UNDYING);
        Bukkit.addRecipe(recipe);
    }

    public NamespacedKey traderRecipeKey() {
        return traderRecipeKey;
    }

    public GemManager gems() {
        return gemManager;
    }
}
