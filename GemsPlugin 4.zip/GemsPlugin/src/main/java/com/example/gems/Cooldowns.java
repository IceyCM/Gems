package com.example.gems;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class Cooldowns {

    private final Map<UUID, Map<String, Long>> ends = new HashMap<>();

    public long remainingMs(UUID id, String key) {
        Map<String, Long> m = ends.get(id);
        if (m == null) return 0L;
        Long end = m.get(key);
        if (end == null) return 0L;
        long left = end - System.currentTimeMillis();
        if (left <= 0L) {
            m.remove(key);
            return 0L;
        }
        return left;
    }

    public void start(UUID id, String key, long ms) {
        ends.computeIfAbsent(id, k -> new HashMap<>()).put(key, System.currentTimeMillis() + ms);
    }

    public void clearAll() {
        ends.clear();
    }

    /** Drops finished cooldowns (called on quit). Running ones stay so relogging can't reset them. */
    public void prune(UUID id) {
        Map<String, Long> m = ends.get(id);
        if (m == null) return;
        long now = System.currentTimeMillis();
        m.values().removeIf(t -> t <= now);
        if (m.isEmpty()) ends.remove(id);
    }

    public static String format(long ms) {
        long s = (ms + 999) / 1000;
        long m = s / 60;
        return m > 0 ? m + "m " + (s % 60) + "s" : s + "s";
    }
}
