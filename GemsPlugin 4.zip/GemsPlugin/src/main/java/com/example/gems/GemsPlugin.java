package com.example.gems;

import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ShapelessRecipe;
import org.bukkit.plugin.java.JavaPlugin;

public class GemsPlugin extends JavaPlugin {

    private GemManager gemManager;
    private Cooldowns cooldowns;
    private StrengthGem strength;
    private PuffGem puff;
    private SpeedGem speed;
    private GemProtectionListener protection;
    private Advancements advancements;
    private Deaths deaths;
    private Status status;
    private Energy energy;
    private NamespacedKey traderRecipeKey;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        getConfig().options().copyDefaults(true);
        saveConfig();

        cooldowns   = new Cooldowns();
        deaths      = new Deaths(this);
        status      = new Status();
        energy      = new Energy(this);
        gemManager  = new GemManager(this);
        advancements = new Advancements(this);
        advancements.register();

        registerTraderRecipe();

        protection = new GemProtectionListener(this);
        strength   = new StrengthGem(this);
        puff       = new PuffGem(this);
        speed      = new SpeedGem(this);

        var pm = getServer().getPluginManager();
        pm.registerEvents(new JoinListener(this), this);
        pm.registerEvents(protection, this);
        pm.registerEvents(new TraderListener(this), this);
        pm.registerEvents(new AbilityListener(this), this);
        pm.registerEvents(strength, this);
        pm.registerEvents(puff, this);
        pm.registerEvents(speed, this);
        pm.registerEvents(deaths, this);
        pm.registerEvents(status, this);
        pm.registerEvents(energy, this);

        strength.start();
        puff.start();
        speed.start();

        BlissCommand bliss = new BlissCommand(this);
        getCommand("bliss").setExecutor(bliss);
        getCommand("bliss").setTabCompleter(bliss);
        GemsCommand gemsCmd = new GemsCommand(this);
        getCommand("gems").setExecutor(gemsCmd);
        getCommand("gems").setTabCompleter(gemsCmd);

        for (Player p : Bukkit.getOnlinePlayers()) p.discoverRecipe(traderRecipeKey);
        getLogger().info("Gems enabled. Use /bliss start to begin.");
    }

    @Override
    public void onDisable() {
        if (gemManager != null) gemManager.finishAll();
        if (strength != null) strength.shutdown();
        if (status != null) status.clearAll();
    }

    private void registerTraderRecipe() {
        traderRecipeKey = new NamespacedKey(this, "gem_trader");
        ShapelessRecipe recipe = new ShapelessRecipe(traderRecipeKey, gemManager.createTrader());
        recipe.addIngredient(2, Material.NETHERITE_INGOT);
        recipe.addIngredient(2, Material.NAUTILUS_SHELL);
        recipe.addIngredient(1, Material.ENCHANTED_GOLDEN_APPLE);
        recipe.addIngredient(4, Material.TOTEM_OF_UNDYING);
        Bukkit.addRecipe(recipe);
    }

    public void sweepBundles(Player p) { protection.sweepBundles(p); }

    public NamespacedKey traderRecipeKey() { return traderRecipeKey; }
    public GemManager gems()         { return gemManager; }
    public Cooldowns cooldowns()     { return cooldowns; }
    public StrengthGem strength()    { return strength; }
    public PuffGem puff()            { return puff; }
    public SpeedGem speed()          { return speed; }
    public Advancements advancements(){ return advancements; }
    public Deaths deaths()           { return deaths; }
    public Status status()           { return status; }
    public Energy energy()           { return energy; }
}
