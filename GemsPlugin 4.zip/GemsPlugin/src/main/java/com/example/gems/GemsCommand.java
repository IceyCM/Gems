package com.example.gems;

import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.configuration.file.FileConfiguration;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** In-game config editor: /gems list|get|set|reload */
public class GemsCommand implements CommandExecutor, TabCompleter {

    private static final String USAGE = "§eUsage: /gems <list [filter]|get <key>|set <key> <value>|reload>";

    private final GemsPlugin plugin;

    public GemsCommand(GemsPlugin plugin) {
        this.plugin = plugin;
    }

    private List<String> leafKeys() {
        FileConfiguration cfg = plugin.getConfig();
        List<String> out = new ArrayList<>();
        for (String k : cfg.getKeys(true)) {
            if (!cfg.isConfigurationSection(k)) out.add(k);
        }
        return out;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (args.length == 0) {
            sender.sendMessage(USAGE);
            return true;
        }
        FileConfiguration cfg = plugin.getConfig();

        switch (args[0].toLowerCase(Locale.ROOT)) {
            case "list" -> {
                String filter = args.length > 1 ? args[1].toLowerCase(Locale.ROOT) : "";
                int shown = 0;
                int total = 0;
                for (String k : leafKeys()) {
                    if (!k.toLowerCase(Locale.ROOT).contains(filter)) continue;
                    total++;
                    if (shown < 20) {
                        sender.sendMessage("§7" + k + " §f= §e" + cfg.get(k));
                        shown++;
                    }
                }
                if (total == 0) sender.sendMessage("§cNo settings match.");
                else if (total > shown) sender.sendMessage("§7...and " + (total - shown) + " more. Add a filter, e.g. /gems list chad");
            }
            case "get" -> {
                if (args.length < 2) {
                    sender.sendMessage("§eUsage: /gems get <key>");
                    return true;
                }
                if (!cfg.contains(args[1]) || cfg.isConfigurationSection(args[1])) {
                    sender.sendMessage("§cUnknown setting. Use /gems list to see them.");
                    return true;
                }
                sender.sendMessage("§7" + args[1] + " §f= §e" + cfg.get(args[1]));
            }
            case "set" -> {
                if (args.length < 3) {
                    sender.sendMessage("§eUsage: /gems set <key> <value>");
                    return true;
                }
                String key = args[1];
                Object old = cfg.get(key);
                if (old == null || cfg.isConfigurationSection(key)) {
                    sender.sendMessage("§cUnknown setting. Use /gems list to see them.");
                    return true;
                }
                Object value;
                try {
                    String raw = args[2];
                    if (old instanceof Boolean) {
                        if (!raw.equalsIgnoreCase("true") && !raw.equalsIgnoreCase("false")) {
                            sender.sendMessage("§cThat setting needs true or false.");
                            return true;
                        }
                        value = Boolean.parseBoolean(raw);
                    } else if (old instanceof Integer) {
                        int n = Integer.parseInt(raw);
                        if (n < 0) throw new NumberFormatException();
                        value = n;
                    } else if (old instanceof Number) {
                        double n = Double.parseDouble(raw);
                        if (n < 0 || Double.isNaN(n) || Double.isInfinite(n)) throw new NumberFormatException();
                        value = n;
                    } else {
                        value = String.join(" ", java.util.Arrays.copyOfRange(args, 2, args.length));
                    }
                } catch (NumberFormatException ex) {
                    sender.sendMessage("§cThat setting needs a "
                            + (old instanceof Integer ? "whole number" : "number") + " (0 or higher).");
                    return true;
                }
                cfg.set(key, value);
                plugin.saveConfig();
                sender.sendMessage("§aSet §f" + key + " §ato §e" + value + "§a.");
            }
            case "reload" -> {
                plugin.reloadConfig();
                sender.sendMessage("§aConfig reloaded.");
            }
            default -> sender.sendMessage(USAGE);
        }
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command cmd, String alias, String[] args) {
        List<String> out = new ArrayList<>();
        if (args.length == 1) {
            for (String s : List.of("list", "get", "set", "reload")) {
                if (s.startsWith(args[0].toLowerCase(Locale.ROOT))) out.add(s);
            }
        } else if (args.length == 2 && (args[0].equalsIgnoreCase("get") || args[0].equalsIgnoreCase("set"))) {
            String prefix = args[1].toLowerCase(Locale.ROOT);
            for (String k : leafKeys()) {
                if (k.toLowerCase(Locale.ROOT).startsWith(prefix)) {
                    out.add(k);
                    if (out.size() >= 40) break;
                }
            }
        }
        return out;
    }
}
