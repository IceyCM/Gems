package com.example.gems;

import java.util.List;

/** The selectable abilities of each gem, in cycling order. */
public final class Abilities {

    private static final List<String> STRENGTH = List.of("Chad Strength","Fractured","Super Smash","Frailer");
    private static final List<String> PUFF = List.of("Dash","Puff Slam","Tornado","Air Lock","Updraft");
    private static final List<String> SPEED = List.of("Static Recall","Speedy Boi","Blur","Dazzling Stun","Overdrive");

    private Abilities() {}

    public static List<String> names(GemType type) {
        return switch (type) {
            case STRENGTH -> STRENGTH;
            case PUFF -> PUFF;
            case SPEED -> SPEED;
            default -> List.of();
        };
    }
}
