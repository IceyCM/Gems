package com.example.gems;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Bukkit;
import org.bukkit.Color;
import org.bukkit.FluidCollisionMode;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.ArmorStand;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.EntityDamageEvent.DamageCause;
import org.bukkit.event.entity.EntityPotionEffectEvent;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.player.PlayerItemConsumeEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerToggleSneakEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.util.Vector;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/** Everything the Strength gem does. All numbers come from config.yml under "strength.". */
public class StrengthGem implements Listener {

    private static final String[] KEYS = {"chad", "fractured", "smash", "frailer"};
    private static final double[] DEFAULT_COOLDOWN = {80.0, 80.0, 60.0, 150.0};
    private static final Particle.DustOptions RED = new Particle.DustOptions(Color.RED, 1.3f);

    /** Effects Frailer strips and blocks. */
    private static final Set<PotionEffectType> BUFFS = Set.of(
            PotionEffectType.SPEED, PotionEffectType.HASTE, PotionEffectType.STRENGTH,
            PotionEffectType.JUMP_BOOST, PotionEffectType.REGENERATION, PotionEffectType.RESISTANCE,
            PotionEffectType.FIRE_RESISTANCE, PotionEffectType.WATER_BREATHING, PotionEffectType.INVISIBILITY,
            PotionEffectType.NIGHT_VISION, PotionEffectType.HEALTH_BOOST, PotionEffectType.ABSORPTION,
            PotionEffectType.SATURATION, PotionEffectType.LUCK, PotionEffectType.SLOW_FALLING,
            PotionEffectType.CONDUIT_POWER, PotionEffectType.DOLPHINS_GRACE,
            PotionEffectType.HERO_OF_THE_VILLAGE, PotionEffectType.WEAVING);

    private static final class Frail {
        long end;
        final List<PotionEffect> stash;
        Frail(long end, List<PotionEffect> stash) {
            this.end = end;
            this.stash = stash;
        }
    }

    private final GemsPlugin plugin;
    private final Deaths deaths;
    private final GemManager gems;
    private final Cooldowns cd;

    private final Map<UUID, Long> chadUntil = new HashMap<>();
    private final Map<UUID, Long> fracturedUntil = new HashMap<>();
    private final Map<UUID, long[]> smash = new HashMap<>();   // {levitation ends, state expires}
    private final Map<UUID, long[]> armed = new HashMap<>();   // {ready from, expires}
    private final Map<UUID, int[]> counters = new HashMap<>(); // 0 chad, 1 smash atk, 2 nulify, 3 burst, 4 refractive
    private final Map<UUID, double[]> lastHit = new HashMap<>();
    private final Map<UUID, Frail> frailed = new HashMap<>();
    private final Set<UUID> passive = new HashSet<>();
    private final Map<UUID, Long> sneakStart = new HashMap<>();

    private int internal = 0;    // >0 while the plugin itself is dealing damage (prevents loops)
    private int tickCounter = 0;

    public StrengthGem(GemsPlugin plugin) {
        this.plugin = plugin;
        this.gems = plugin.gems();
        this.cd = plugin.cooldowns();
        this.deaths = plugin.deaths();
    }

    public void start() {
        Bukkit.getScheduler().runTaskTimer(plugin, this::tick, 2L, 2L);
    }

    /** Gives frailed players their effects back (used on shutdown/reload). */
    public void shutdown() {
        for (Map.Entry<UUID, Frail> en : new ArrayList<>(frailed.entrySet())) {
            Player p = Bukkit.getPlayer(en.getKey());
            frailed.remove(en.getKey());
            if (p != null) restore(p, en.getValue());
        }
    }

    /** Clears all running abilities and effects (used by /bliss reset). */
    public void resetAll() {
        shutdown();
        chadUntil.clear();
        fracturedUntil.clear();
        smash.clear();
        armed.clear();
        counters.clear();
        lastHit.clear();
        sneakStart.clear();
    }

    // ---------------------------------------------------------------- config helpers

    private double d(String k, double def) { return plugin.getConfig().getDouble("strength." + k, def); }
    private int i(String k, int def) { return Math.max(1, plugin.getConfig().getInt("strength." + k, def)); }
    private long ms(String k, double defSeconds) { return (long) (d(k, defSeconds) * 1000.0); }
    private int ticks(String k, double defSeconds) { return (int) Math.max(1, d(k, defSeconds) * 20.0); }
    private int amp(String k, int defLevel) { return Math.max(0, plugin.getConfig().getInt("strength." + k, defLevel) - 1); }

    private static long now() { return System.currentTimeMillis(); }

    private boolean isStrengthGem(ItemStack it) { return gems.getGem(it) == GemType.STRENGTH; }
    private boolean offGem(Player p) { return isStrengthGem(p.getInventory().getItemInOffHand()); }
    private static boolean isSword(ItemStack it) { return it != null && it.getType().name().endsWith("_SWORD"); }
    private static boolean isAxe(ItemStack it) { return it != null && it.getType().name().endsWith("_AXE"); }
    private boolean cdOn(Player p, String key) { return cd.remainingMs(p.getUniqueId(), key) > 0L; }

    private void bar(Player p, String msg, NamedTextColor color) {
        p.sendActionBar(Component.text(msg, color));
    }

    private int[] counters(UUID id) { return counters.computeIfAbsent(id, k -> new int[5]); }

    private void hurt(LivingEntity t, double amount, Player source) {
        if (t.equals(source)) return;
        internal++;
        try {
            t.setNoDamageTicks(0);
            t.setHealth(Math.max(0, t.getHealth() - amount * 2.0));
            if (t.getHealth() <= 0 && t instanceof Player v)
                deaths.record(v.getUniqueId(), source.getUniqueId(), "strength.smash");
        } finally {
            internal--;
        }
    }

    private Player nearest(Player p, double radius) {
        Player best = null;
        double bestDist = Double.MAX_VALUE;
        Location from = p.getLocation();
        for (Player o : p.getWorld().getNearbyPlayers(from, radius)) {
            if (o.equals(p) || o.isDead() || o.getGameMode() == GameMode.SPECTATOR) continue;
            double dist = o.getLocation().distanceSquared(from);
            if (dist < bestDist) {
                bestDist = dist;
                best = o;
            }
        }
        return best;
    }

    /** Vanilla critical-hit conditions. */
    private static boolean isCrit(Player p) {
        return p.getFallDistance() > 0.0f && !p.isOnGround() && !p.isClimbing() && !p.isInWater()
                && !p.hasPotionEffect(PotionEffectType.BLINDNESS) && !p.isInsideVehicle()
                && !p.isSprinting() && p.getAttackCooldown() > 0.848f;
    }

    private boolean nearGround(Player p) {
        return p.getWorld().rayTraceBlocks(p.getLocation(), new Vector(0, -1, 0),
                d("smash-attack.ground-distance", 3.0), FluidCollisionMode.NEVER, true) != null;
    }

    // ---------------------------------------------------------------- activation

    public void activate(Player p, int idx) {
        if (idx < 0 || idx >= KEYS.length) return;
        UUID id = p.getUniqueId();
        String key = KEYS[idx];
        String name = Abilities.names(GemType.STRENGTH).get(idx);

        long left = cd.remainingMs(id, key);
        if (left > 0L) {
            bar(p, name + " is on cooldown: " + Cooldowns.format(left), NamedTextColor.RED);
            return;
        }

        long now = now();
        switch (idx) {
            case 0 -> {
                chadUntil.put(id, now + ms("chad.duration-seconds", 15.0));
                counters(id)[0] = 0;
                p.getWorld().playSound(p.getLocation(), Sound.ENTITY_ENDER_DRAGON_GROWL, 0.8f, 1.2f);
            }
            case 1 -> {
                fracturedUntil.put(id, now + ms("fractured.duration-seconds", 10.0));
                p.getWorld().playSound(p.getLocation(), Sound.ITEM_SHIELD_BLOCK, 1.0f, 0.8f);
            }
            case 2 -> {
                int lt = ticks("smash.levitation-seconds", 2.0);
                p.addPotionEffect(new PotionEffect(PotionEffectType.LEVITATION, lt,
                        amp("smash.levitation-level", 4), false, true, true));
                smash.put(id, new long[]{now + lt * 50L, now + lt * 50L + 20000L});
                p.getWorld().playSound(p.getLocation(), Sound.ENTITY_PLAYER_ATTACK_KNOCKBACK, 1.0f, 0.6f);
            }
            default -> {
                long end = now + ms("frailer.duration-seconds", 15.0);
                for (Player t : Bukkit.getOnlinePlayers()) {
                    if (!t.equals(p)) frail(t, end);
                }
                p.getWorld().playSound(p.getLocation(), Sound.ENTITY_WITHER_AMBIENT, 1.0f, 1.0f);
            }
        }

        cd.start(id, key, ms(key + ".cooldown-seconds", DEFAULT_COOLDOWN[idx]));
        bar(p, name + " activated!", NamedTextColor.GOLD);
    }

    // ---------------------------------------------------------------- frailer

    private void frail(Player t, long end) {
        UUID id = t.getUniqueId();
        Frail existing = frailed.get(id);
        if (existing != null) {
            existing.end = Math.max(existing.end, end);
            return;
        }
        List<PotionEffect> stash = new ArrayList<>();
        for (PotionEffect pe : t.getActivePotionEffects()) {
            if (BUFFS.contains(pe.getType())) stash.add(pe);
        }
        frailed.put(id, new Frail(end, stash));
        for (PotionEffect pe : stash) t.removePotionEffect(pe.getType());
        bar(t, "You have been Frailed!", NamedTextColor.RED);
        t.playSound(t.getLocation(), Sound.ENTITY_WITHER_HURT, 0.7f, 0.8f);
    }

    /** Gives back stashed effects with the time they had left when they were taken. */
    private void restore(Player p, Frail f) {
        for (PotionEffect pe : f.stash) {
            PotionEffect cur = p.getPotionEffect(pe.getType());
            boolean better = cur == null
                    || cur.getAmplifier() < pe.getAmplifier()
                    || (cur.getAmplifier() == pe.getAmplifier() && cur.getDuration() != -1
                        && (pe.getDuration() == -1 || pe.getDuration() > cur.getDuration()));
            if (better) p.addPotionEffect(pe);
        }
    }

    @EventHandler(ignoreCancelled = true)
    public void onEffect(EntityPotionEffectEvent e) {
        if (frailed.isEmpty() || !(e.getEntity() instanceof Player p) || !frailed.containsKey(p.getUniqueId())) return;
        PotionEffect ne = e.getNewEffect();
        if (ne == null) return;
        EntityPotionEffectEvent.Action a = e.getAction();
        if ((a == EntityPotionEffectEvent.Action.ADDED || a == EntityPotionEffectEvent.Action.CHANGED)
                && BUFFS.contains(ne.getType())) {
            e.setCancelled(true);
        }
    }

    @EventHandler(ignoreCancelled = true)
    public void onConsume(PlayerItemConsumeEvent e) {
        if (e.getItem().getType() == Material.POTION && frailed.containsKey(e.getPlayer().getUniqueId())) {
            e.setCancelled(true);
            bar(e.getPlayer(), "You can't use potions while Frailed.", NamedTextColor.RED);
        }
    }

    // ---------------------------------------------------------------- damage taken

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onAnyDamage(EntityDamageEvent e) {
        if (internal > 0 || !(e.getEntity() instanceof Player v)) return;
        UUID id = v.getUniqueId();
        DamageCause cause = e.getCause();

        // No fall damage for the Super Smash / Smash Attack landing.
        if (cause == DamageCause.FALL && (smash.containsKey(id) || armed.containsKey(id))) {
            e.setCancelled(true);
            return;
        }

        Long until = fracturedUntil.get(id);
        if (until == null || until <= now()) return;
        if (cause == DamageCause.VOID || cause == DamageCause.KILL || cause == DamageCause.SUICIDE) return;

        double reduction = Math.max(0.0, Math.min(1.0, d("fractured.reduction", 0.5)));
        double reflected = e.getFinalDamage() * reduction;
        if (reflected <= 0.0) return;
        e.setDamage(e.getDamage() * (1.0 - reduction));
        wave(v, reflected);
    }

    private void wave(Player v, double amount) {
        double dmg = Math.min(amount, d("fractured.max-reflect-hearts", 6.0) * 2.0);
        double r = d("fractured.radius", 4.0);
        for (Entity en : v.getNearbyEntities(r, r, r)) {
            if (!(en instanceof LivingEntity le) || le instanceof ArmorStand || le.isDead()) continue;
            if (le instanceof Player pl && pl.getGameMode() == GameMode.SPECTATOR) continue;
            hurt(le, dmg, v);
        }
        Location l = v.getLocation().add(0, 0.5, 0);
        v.getWorld().spawnParticle(Particle.SWEEP_ATTACK, l, 12, r / 2.0, 0.2, r / 2.0, 0);
        v.getWorld().playSound(l, Sound.ENTITY_PLAYER_ATTACK_SWEEP, 1.0f, 0.7f);
    }

    // ---------------------------------------------------------------- damage dealt

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onHit(EntityDamageByEntityEvent e) {
        if (internal > 0) return;

        if (e.getDamager() instanceof Player a && e.getEntity() instanceof LivingEntity t && !(t instanceof ArmorStand)) {
            if (e.getCause() == DamageCause.ENTITY_SWEEP_ATTACK) {
                sweep(a, e);
            } else if (e.getCause() == DamageCause.ENTITY_ATTACK) {
                melee(a, t, e);
            }
        }
        if (e.getEntity() instanceof Player v && e.getCause() == DamageCause.ENTITY_ATTACK) {
            refractive(v, e);
        }
    }

    private void melee(Player a, LivingEntity target, EntityDamageByEntityEvent e) {
        if (gems.isRolling(a)) return;
        UUID id = a.getUniqueId();
        long now = now();
        ItemStack main = a.getInventory().getItemInMainHand();
        boolean sword = isSword(main);
        boolean axe = isAxe(main);
        boolean off = offGem(a);
        boolean crit = isCrit(a);
        int[] c = counters(id);

        // Smash Attack: axe hit right before landing deals bonus damage (mace style).
        long[] arm = armed.get(id);
        if (arm != null && axe && now >= arm[0] && !a.isOnGround() && a.getFallDistance() > 0.0f && nearGround(a)) {
            armed.remove(id);
            e.setDamage(e.getDamage() * d("smash-attack.damage-multiplier", 3.0));
            Location l = target.getLocation().add(0, 1, 0);
            target.getWorld().spawnParticle(Particle.EXPLOSION, l, 2, 0.3, 0.3, 0.3, 0);
            target.getWorld().playSound(l, Sound.ENTITY_GENERIC_EXPLODE, 0.8f, 1.3f);
        }

        if (crit) {
            Long cu = chadUntil.get(id);
            if (cu != null && cu > now && ++c[0] >= i("chad.crit-interval", 4)) {
                c[0] = 0;
                e.setDamage(e.getDamage() * d("chad.damage-multiplier", 2.0));
                Location l = target.getLocation().add(0, 1, 0);
                target.getWorld().spawnParticle(Particle.DUST, l, 30, 0.4, 0.5, 0.4, 0, RED);
                target.getWorld().playSound(l, Sound.ENTITY_WARDEN_ATTACK_IMPACT, 1.0f, 1.0f);
            }
            if (off && axe && cdOn(a, "smash") && ++c[1] >= i("smash-attack.crit-interval", 15)) {
                c[1] = 0;
                startSmashAttack(a);
            }
        }

        if (off && sword && cdOn(a, "chad") && ++c[3] >= i("burst.hit-interval", 8)) {
            c[3] = 0;
            a.addPotionEffect(new PotionEffect(PotionEffectType.STRENGTH, ticks("burst.strength-seconds", 3.0),
                    amp("burst.strength-level", 2)));
            bar(a, "Burst Damage!", NamedTextColor.RED);
        }

        if (off && axe && cdOn(a, "frailer") && ++c[2] >= i("nulify.hit-interval", 5)) {
            c[2] = 0;
            nulify(a);
        }

        if (target instanceof Player && (off || isStrengthGem(main)) && !cdOn(a, "diminish")) {
            diminish(a);
        }

        lastHit.put(id, new double[]{e.getDamage(), Bukkit.getCurrentTick()});
    }

    /** Heavy Swing: sweep hits deal the same damage as the main hit. */
    private void sweep(Player a, EntityDamageByEntityEvent e) {
        if (gems.isRolling(a)) return;
        if (!plugin.getConfig().getBoolean("strength.heavy-swing.enabled", true) || !offGem(a)) return;
        double[] h = lastHit.get(a.getUniqueId());
        if (h != null && (int) h[1] == Bukkit.getCurrentTick()) e.setDamage(h[0]);
    }

    private void refractive(Player v, EntityDamageByEntityEvent e) {
        if (!(e.getDamager() instanceof LivingEntity le) || le.getEquipment() == null
                || !isSword(le.getEquipment().getItemInMainHand())) return;
        if (!offGem(v) || !cdOn(v, "fractured")) return;
        int[] c = counters(v.getUniqueId());
        if (++c[4] < i("refractive.hit-interval", 8)) return;
        c[4] = 0;
        Player n = nearest(v, d("refractive.radius", 5.0));
        if (n == null) return;
        hurt(n, d("refractive.damage-hearts", 2.5) * 2.0, v);
        n.getWorld().spawnParticle(Particle.DUST, n.getLocation().add(0, 1, 0), 25, 0.4, 0.5, 0.4, 0, RED);
        bar(v, "Refractive Blood!", NamedTextColor.RED);
    }

    private void nulify(Player a) {
        double r = d("nulify.radius", 5.0);
        a.addPotionEffect(new PotionEffect(PotionEffectType.RESISTANCE, ticks("nulify.resistance-seconds", 2.0),
                amp("nulify.resistance-level", 2)));
        Player n = nearest(a, r);
        if (n != null) {
            n.addPotionEffect(new PotionEffect(PotionEffectType.WEAKNESS, ticks("nulify.weakness-seconds", 2.0),
                    amp("nulify.weakness-level", 2)));
        }
        bar(a, "Nulify!", NamedTextColor.GRAY);
    }

    private void diminish(Player a) {
        Player n = nearest(a, d("diminish.radius", 5.0));
        if (n == null) return;
        n.addPotionEffect(new PotionEffect(PotionEffectType.WEAKNESS, ticks("diminish.weakness-seconds", 15.0),
                amp("diminish.weakness-level", 4)));
        cd.start(a.getUniqueId(), "diminish", ms("diminish.cooldown-seconds", 60.0));
        bar(a, "Diminish!", NamedTextColor.GRAY);
    }

    private void startSmashAttack(Player a) {
        int lt = ticks("smash-attack.levitation-seconds", 1.0);
        a.addPotionEffect(new PotionEffect(PotionEffectType.LEVITATION, lt,
                amp("smash-attack.levitation-level", 3), false, true, true));
        long now = now();
        armed.put(a.getUniqueId(), new long[]{now + lt * 50L + 300L, now + ms("smash-attack.timeout-seconds", 10.0)});
        bar(a, "Smash Attack ready! Land an axe hit just before the ground.", NamedTextColor.GOLD);
    }

    // ---------------------------------------------------------------- sharpness enchant

    @EventHandler
    public void onSneak(PlayerToggleSneakEvent e) {
        UUID id = e.getPlayer().getUniqueId();
        if (e.isSneaking()) sneakStart.put(id, now());
        else sneakStart.remove(id);
    }

    /** Called once the player has held sneak long enough. Permanently enchants the offhand weapon. */
    private void tryEnchant(Player p) {
        if (gems.isRolling(p)) return;
        if (!gems.isStarted()) return;
        UUID id = p.getUniqueId();
        if (!isStrengthGem(p.getInventory().getItemInMainHand())) return;
        ItemStack off = p.getInventory().getItemInOffHand();
        if (!isSword(off) && !isAxe(off)) return;
        if (cd.remainingMs(id, "sharp") > 0L) return; // silent: no spam while holding sneak

        int level = plugin.getConfig().getInt("strength.sharpness.level", 5);
        ItemMeta meta = off.getItemMeta();
        if (meta.getEnchantLevel(Enchantment.SHARPNESS) >= level) {
            bar(p, "That weapon already has high enough Sharpness.", NamedTextColor.GRAY);
            return;
        }
        meta.addEnchant(Enchantment.SHARPNESS, level, true);
        off.setItemMeta(meta);
        p.getInventory().setItemInOffHand(off);

        cd.start(id, "sharp", ms("sharpness.cooldown-seconds", 180.0));
        bar(p, "Your weapon now has Sharpness " + level + "!", NamedTextColor.RED);
        p.playSound(p.getLocation(), Sound.BLOCK_ENCHANTMENT_TABLE_USE, 1.0f, 1.0f);
    }

    // ---------------------------------------------------------------- Super Smash landing

    private void shockwave(Player p) {
        double r = d("smash.radius", 5.0);
        double dmg = d("smash.damage-hearts", 5.0) * 2.0;
        int secs = ticks("smash.effect-seconds", 5.0);
        Location loc = p.getLocation();
        for (Player t : new ArrayList<>(p.getWorld().getNearbyPlayers(loc, r))) {
            if (t.equals(p) || t.isDead() || t.getGameMode() == GameMode.SPECTATOR) continue;
            hurt(t, dmg, p);
            t.addPotionEffect(new PotionEffect(PotionEffectType.NAUSEA, secs, amp("smash.nausea-level", 5)));
            t.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS, secs, amp("smash.slowness-level", 5)));
        }
        p.getWorld().spawnParticle(Particle.EXPLOSION, loc, 4, r / 3.0, 0.2, r / 3.0, 0);
        p.getWorld().playSound(loc, Sound.ENTITY_GENERIC_EXPLODE, 1.0f, 0.8f);
    }

    // ---------------------------------------------------------------- one shared timer

    private void tick() {
        tickCounter++;
        long now = now();

        if (!smash.isEmpty()) {
            List<UUID> landed = new ArrayList<>();
            Iterator<Map.Entry<UUID, long[]>> it = smash.entrySet().iterator();
            while (it.hasNext()) {
                Map.Entry<UUID, long[]> en = it.next();
                Player p = Bukkit.getPlayer(en.getKey());
                long[] s = en.getValue();
                if (p == null || now > s[1]) {
                    it.remove();
                } else if (now >= s[0] && !p.isDead() && p.isOnGround()) {
                    it.remove();
                    landed.add(en.getKey());
                }
            }
            for (UUID id : landed) {
                Player p = Bukkit.getPlayer(id);
                if (p != null) shockwave(p);
            }
        }

        if (!sneakStart.isEmpty()) {
            long need = ms("sharpness.sneak-seconds", 1.0);
            List<UUID> ready = new ArrayList<>();
            Iterator<Map.Entry<UUID, Long>> sit = sneakStart.entrySet().iterator();
            while (sit.hasNext()) {
                Map.Entry<UUID, Long> en = sit.next();
                Player sp = Bukkit.getPlayer(en.getKey());
                if (sp == null || !sp.isSneaking()) {
                    sit.remove();
                } else if (now - en.getValue() >= need) {
                    sit.remove();
                    ready.add(en.getKey());
                }
            }
            for (UUID id : ready) {
                Player sp = Bukkit.getPlayer(id);
                if (sp != null) tryEnchant(sp);
            }
        }

        if (!armed.isEmpty()) {
            armed.entrySet().removeIf(en -> {
                Player p = Bukkit.getPlayer(en.getKey());
                long[] a = en.getValue();
                return p == null || now > a[1] || (now >= a[0] && p.isOnGround());
            });
        }

        if (tickCounter % 3 == 0 && !chadUntil.isEmpty()) {
            Iterator<Map.Entry<UUID, Long>> it = chadUntil.entrySet().iterator();
            while (it.hasNext()) {
                Map.Entry<UUID, Long> en = it.next();
                Player p = Bukkit.getPlayer(en.getKey());
                if (p == null || en.getValue() <= now) {
                    int[] c = counters.get(en.getKey());
                    if (c != null) c[0] = 0;
                    it.remove();
                    if (p != null) bar(p, "Chad Strength ended.", NamedTextColor.GRAY);
                } else {
                    p.getWorld().spawnParticle(Particle.DUST, p.getLocation().add(0, 1.0, 0), 8, 0.45, 0.8, 0.45, 0, RED);
                }
            }
        }

        if (tickCounter % 5 == 0) {
            fracturedUntil.values().removeIf(t -> t <= now);
            if (!frailed.isEmpty()) {
                List<UUID> done = new ArrayList<>();
                for (Map.Entry<UUID, Frail> en : frailed.entrySet()) {
                    if (en.getValue().end <= now) done.add(en.getKey());
                }
                for (UUID id : done) {
                    Frail f = frailed.remove(id);
                    Player p = Bukkit.getPlayer(id);
                    if (p != null && f != null) {
                        restore(p, f);
                        bar(p, "Frailer wore off. Your effects are back.", NamedTextColor.GREEN);
                    }
                }
            }
            passiveTick();
        }
    }

    /** Permanent Strength while the gem is in the offhand. */
    private void passiveTick() {
        int amp = amp("passive.strength-level", 1);
        boolean on = gems.isStarted();
        for (Player p : Bukkit.getOnlinePlayers()) {
            UUID id = p.getUniqueId();
            if (on && offGem(p) && !frailed.containsKey(id)) {
                PotionEffect cur = p.getPotionEffect(PotionEffectType.STRENGTH);
                if (cur == null || cur.getAmplifier() < amp
                        || (cur.getAmplifier() == amp && cur.getDuration() != -1 && cur.getDuration() < 40)) {
                    p.addPotionEffect(new PotionEffect(PotionEffectType.STRENGTH, 60, amp, true, false, true));
                }
                passive.add(id);
            } else if (passive.remove(id)) {
                PotionEffect cur = p.getPotionEffect(PotionEffectType.STRENGTH);
                if (cur != null && cur.isAmbient() && cur.getAmplifier() == amp && cur.getDuration() <= 60) {
                    p.removePotionEffect(PotionEffectType.STRENGTH);
                }
            }
        }
    }

    // ---------------------------------------------------------------- cleanup

    private void clearState(UUID id) {
        chadUntil.remove(id);
        fracturedUntil.remove(id);
        smash.remove(id);
        armed.remove(id);
        counters.remove(id);
        lastHit.remove(id);
        passive.remove(id);
        sneakStart.remove(id);
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        Player p = e.getPlayer();
        UUID id = p.getUniqueId();
        Frail f = frailed.remove(id);
        if (f != null) restore(p, f); // so their buffs aren't lost while offline
        clearState(id);
        cd.prune(id);
    }

    @EventHandler
    public void onDeath(PlayerDeathEvent e) {
        UUID id = e.getEntity().getUniqueId();
        frailed.remove(id);
        clearState(id);
    }
}
