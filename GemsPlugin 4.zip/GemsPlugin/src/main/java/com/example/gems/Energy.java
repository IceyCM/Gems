package com.example.gems;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextColor;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.World;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Item;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.inventory.PrepareItemCraftEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;

import java.io.File;
import java.io.IOException;
import java.util.List;
import java.util.UUID;

/**
 * The gem energy system. Stage 0 is Pristine; each death drops the victim one stage (to Broken at -5)
 * and the energy goes to the killer (up to Pristine +5) or drops on the ground. Never destroyed.
 */
public class Energy implements Listener {

    public static final int MIN = -5;
    public static final int MAX = 5;

    private final GemsPlugin plugin;
    private final File file;
    private final YamlConfiguration yml;
    private final NamespacedKey itemKey;

    public Energy(GemsPlugin plugin) {
        this.plugin = plugin;
        this.file = new File(plugin.getDataFolder(), "energy.yml");
        this.yml = YamlConfiguration.loadConfiguration(file);
        this.itemKey = new NamespacedKey(plugin, "energy");
    }

    // ------------------------------------------------------------------ stages

    public static String stageName(int s) {
        if (s > 0) return "Pristine +" + s;
        return switch (s) {
            case 0 -> "Pristine";
            case -1 -> "Scratched";
            case -2 -> "Cracked";
            case -3 -> "Damaged";
            case -4 -> "Ruined";
            default -> "Broken";
        };
    }

    public static TextColor stageColor(int s) {
        if (s > 0) return NamedTextColor.GREEN;
        return switch (s) {
            case 0 -> NamedTextColor.AQUA;
            case -1 -> NamedTextColor.YELLOW;
            case -2 -> NamedTextColor.GOLD;
            case -3 -> NamedTextColor.RED;
            case -4 -> NamedTextColor.DARK_RED;
            default -> NamedTextColor.DARK_GRAY;
        };
    }

    public boolean enabled() {
        return plugin.getConfig().getBoolean("energy.enabled", true);
    }

    public void setEnabled(boolean on) {
        plugin.getConfig().set("energy.enabled", on);
        plugin.saveConfig();
        for (Player p : Bukkit.getOnlinePlayers()) plugin.gems().refreshLore(p);
    }

    public int stage(UUID id) {
        return Math.max(MIN, Math.min(MAX, yml.getInt("stage." + id, 0)));
    }

    public boolean isBroken(Player p) {
        return enabled() && stage(p.getUniqueId()) <= MIN;
    }

    private double step() {
        return Math.max(0.0, plugin.getConfig().getDouble("energy.step", 0.04));
    }

    /** Multiplier for cooldowns: below 1 above Pristine, above 1 below it. */
    public double cooldownFactor(Player p) {
        if (!enabled()) return 1.0;
        return Math.max(0.1, 1.0 - step() * stage(p.getUniqueId()));
    }

    /** Multiplier for ability reach (radius, distance): bigger above Pristine, smaller below it. */
    public double reachFactor(Player p) {
        if (!enabled()) return 1.0;
        return Math.max(0.1, 1.0 + step() * stage(p.getUniqueId()));
    }

    public void setStage(UUID id, int newStage, boolean notify) {
        int s = Math.max(MIN, Math.min(MAX, newStage));
        int old = stage(id);
        if (s == old) return;
        yml.set("stage." + id, s);
        save();

        Player p = Bukkit.getPlayer(id);
        if (p == null) return;
        plugin.gems().refreshLore(p);
        if (notify) {
            p.sendActionBar(Component.text("Your gem is now " + stageName(s), stageColor(s)));
        }
        if (s <= MIN) {
            p.sendMessage(Component.text("Your gem has shattered. It can never be recharged.", NamedTextColor.DARK_RED));
            plugin.advancements().award(p, "shattered");
        } else if (s >= MAX) {
            plugin.advancements().award(p, "overcharged");
        }
    }

    /** Wipes everyone's energy (used by /bliss reset). */
    public void reset() {
        yml.set("stage", null);
        save();
    }

    private void save() {
        try {
            yml.save(file);
        } catch (IOException e) {
            plugin.getLogger().severe("Could not save energy.yml: " + e.getMessage());
        }
    }

    // ------------------------------------------------------------------ the energy item

    public ItemStack createEnergyItem() {
        ItemStack item = new ItemStack(Material.GLOW_INK_SAC);
        ItemMeta meta = item.getItemMeta();
        meta.displayName(Component.text("Energy", NamedTextColor.GOLD).decoration(TextDecoration.ITALIC, false));
        meta.lore(List.of(Component.text("Right-click to raise your gem one stage.", NamedTextColor.GRAY)
                .decoration(TextDecoration.ITALIC, false)));
        meta.setEnchantmentGlintOverride(true);
        meta.getPersistentDataContainer().set(itemKey, PersistentDataType.BYTE, (byte) 1);
        item.setItemMeta(meta);
        return item;
    }

    public boolean isEnergyItem(ItemStack item) {
        return item != null && item.getType() == Material.GLOW_INK_SAC && item.hasItemMeta()
                && item.getItemMeta().getPersistentDataContainer().has(itemKey, PersistentDataType.BYTE);
    }

    /** Drops an Energy item that can't burn, despawn or blow up. */
    public void dropEnergy(Location where) {
        World w = where.getWorld();
        if (w == null) return;
        Location loc = where;
        if (loc.getY() < w.getMinHeight() + 1) loc = w.getSpawnLocation(); // fell into the void
        Item drop = w.dropItemNaturally(loc, createEnergyItem());
        drop.setUnlimitedLifetime(true);
        drop.setInvulnerable(true);
        drop.setGlowing(true);
    }

    // ------------------------------------------------------------------ events

    @EventHandler(priority = EventPriority.MONITOR)
    public void onDeath(PlayerDeathEvent e) {
        if (!enabled() || !plugin.gems().isStarted()) return;
        Player victim = e.getEntity();
        UUID vid = victim.getUniqueId();
        if (!plugin.gems().hasReceived(vid)) return;

        int vs = stage(vid);
        if (vs <= MIN) return; // already broken: nothing left to lose
        setStage(vid, vs - 1, true);

        Player killer = plugin.deaths().killerOf(victim);
        if (killer != null && plugin.gems().hasReceived(killer.getUniqueId())) {
            int ks = stage(killer.getUniqueId());
            if (ks > MIN && ks < MAX) {
                setStage(killer.getUniqueId(), ks + 1, true);
                return; // the energy moved to the killer
            }
        }
        dropEnergy(victim.getLocation()); // no credit, or the killer's gem can't take it
    }

    @EventHandler
    public void onUse(PlayerInteractEvent e) {
        if (e.getHand() != EquipmentSlot.HAND) return;
        if (e.getAction() != Action.RIGHT_CLICK_AIR && e.getAction() != Action.RIGHT_CLICK_BLOCK) return;
        if (!isEnergyItem(e.getItem())) return;
        e.setCancelled(true);

        Player p = e.getPlayer();
        UUID id = p.getUniqueId();
        if (plugin.gems().isRolling(p)) return;
        if (!enabled() || !plugin.gems().isStarted()) {
            p.sendActionBar(Component.text("Energy isn't active.", NamedTextColor.GRAY));
            return;
        }
        if (!plugin.gems().hasReceived(id)) {
            p.sendActionBar(Component.text("You don't have a gem.", NamedTextColor.RED));
            return;
        }
        int s = stage(id);
        if (s <= MIN) {
            p.sendActionBar(Component.text("Your gem is broken. Energy can't be added back.", NamedTextColor.RED));
            return;
        }
        if (s >= MAX) {
            p.sendActionBar(Component.text("Your gem is already at Pristine +5.", NamedTextColor.GRAY));
            return;
        }
        ItemStack hand = p.getInventory().getItemInMainHand();
        if (hand.getAmount() <= 1) p.getInventory().setItemInMainHand(null);
        else hand.setAmount(hand.getAmount() - 1);
        setStage(id, s + 1, true);
    }

    // The Energy item is a glow ink sac underneath; keep it out of crafting.
    @EventHandler
    public void onCraft(PrepareItemCraftEvent e) {
        for (ItemStack it : e.getInventory().getMatrix()) {
            if (isEnergyItem(it)) {
                e.getInventory().setResult(null);
                return;
            }
        }
    }
}
