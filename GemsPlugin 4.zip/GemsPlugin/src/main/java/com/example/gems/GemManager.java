package com.example.gems;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import net.kyori.adventure.title.Title;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.Sound;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;

import java.io.File;
import java.io.IOException;
import java.time.Duration;
import java.util.ArrayList;
import java.util.EnumSet;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ThreadLocalRandom;

public class GemManager {

    /** Every material a gem can be. Checked first so ordinary items never touch item meta. */
    private static final EnumSet<Material> GEM_MATERIALS = EnumSet.noneOf(Material.class);
    static {
        for (GemType t : GemType.values()) GEM_MATERIALS.add(t.material());
    }

    /** The gem a player is rolling towards is decided up front, so leaving mid-roll can't dodge it. */
    private static final class Roll {
        final GemType target;
        final boolean trade;
        final int slot;            // inventory slot that shows the cycling gem (-1 = none)
        final ItemStack original;  // their real gem before a trade roll started

        Roll(GemType target, boolean trade, int slot, ItemStack original) {
            this.target = target;
            this.trade = trade;
            this.slot = slot;
            this.original = original;
        }
    }

    private final GemsPlugin plugin;
    private final NamespacedKey gemKey;
    private final NamespacedKey traderKey;
    private final NamespacedKey selKey;
    private final NamespacedKey genKey;
    private final NamespacedKey rollKey;
    private final Map<UUID, Roll> rolling = new HashMap<>();
    private final Set<UUID> pending = new HashSet<>();
    private final File dataFile;
    private final YamlConfiguration data;
    private int generation;

    public GemManager(GemsPlugin plugin) {
        this.plugin = plugin;
        this.gemKey = new NamespacedKey(plugin, "gem");
        this.traderKey = new NamespacedKey(plugin, "trader");
        this.selKey = new NamespacedKey(plugin, "sel");
        this.genKey = new NamespacedKey(plugin, "gen");
        this.rollKey = new NamespacedKey(plugin, "roll");
        this.dataFile = new File(plugin.getDataFolder(), "data.yml");
        this.data = YamlConfiguration.loadConfiguration(dataFile);
        this.generation = data.getInt("generation", 0);
    }

    // ================================================================ gem items

    public ItemStack createGem(GemType type) {
        return createGem(type, null);
    }

    public ItemStack createGem(GemType type, Player owner) {
        ItemStack item = new ItemStack(type.material());
        ItemMeta meta = item.getItemMeta();
        meta.displayName(Component.text(type.displayName() + " Gem", type.color())
                .decoration(TextDecoration.ITALIC, false));
        meta.lore(GemInfo.lore(type, 0, owner, plugin));
        meta.setEnchantmentGlintOverride(true);
        meta.setMaxStackSize(1);
        meta.getPersistentDataContainer().set(gemKey, PersistentDataType.STRING, type.name());
        meta.getPersistentDataContainer().set(genKey, PersistentDataType.INTEGER, generation);
        item.setItemMeta(meta);
        return item;
    }

    /** Rebuilds the description on the player's gem (after an energy change). */
    public void refreshLore(Player p) {
        if (isRolling(p)) return;
        int slot = findGemSlot(p);
        if (slot < 0) return;
        ItemStack it = p.getInventory().getItem(slot);
        GemType type = getGem(it);
        if (type == null) return;
        int sel = getSelected(it, Math.max(1, Abilities.names(type).size()));
        ItemMeta meta = it.getItemMeta();
        meta.lore(GemInfo.lore(type, sel, p, plugin));
        it.setItemMeta(meta);
        p.getInventory().setItem(slot, it);
    }

    /** Index of the ability selected on this gem (0 if none stored). */
    public int getSelected(ItemStack item, int size) {
        if (item == null || !item.hasItemMeta() || size <= 0) return 0;
        Integer v = item.getItemMeta().getPersistentDataContainer().get(selKey, PersistentDataType.INTEGER);
        return (v == null || v < 0 || v >= size) ? 0 : v;
    }

    public void setSelected(ItemStack item, GemType type, int sel, Player owner) {
        ItemMeta meta = item.getItemMeta();
        meta.getPersistentDataContainer().set(selKey, PersistentDataType.INTEGER, sel);
        meta.lore(GemInfo.lore(type, sel, owner, plugin));
        item.setItemMeta(meta);
    }

    public boolean isGem(ItemStack item) {
        return getGem(item) != null;
    }

    /** Returns the gem type of an item, or null if it isn't a (current, real) gem. */
    public GemType getGem(ItemStack item) {
        if (item == null || !GEM_MATERIALS.contains(item.getType()) || !item.hasItemMeta()) return null;
        var pdc = item.getItemMeta().getPersistentDataContainer();
        if (pdc.has(rollKey, PersistentDataType.BYTE)) return null; // animation-only item
        String id = pdc.get(gemKey, PersistentDataType.STRING);
        if (id == null) return null;
        Integer gen = pdc.get(genKey, PersistentDataType.INTEGER);
        if ((gen == null ? 0 : gen) != generation) return null;
        try {
            return GemType.valueOf(id);
        } catch (IllegalArgumentException e) {
            return null;
        }
    }

    public boolean isRollItem(ItemStack item) {
        return item != null && GEM_MATERIALS.contains(item.getType()) && item.hasItemMeta()
                && item.getItemMeta().getPersistentDataContainer().has(rollKey, PersistentDataType.BYTE);
    }

    private boolean isStaleGem(ItemStack item) {
        if (item == null || !GEM_MATERIALS.contains(item.getType()) || !item.hasItemMeta()) return false;
        var pdc = item.getItemMeta().getPersistentDataContainer();
        if (pdc.has(rollKey, PersistentDataType.BYTE) || !pdc.has(gemKey, PersistentDataType.STRING)) return false;
        Integer gen = pdc.get(genKey, PersistentDataType.INTEGER);
        return (gen == null ? 0 : gen) != generation;
    }

    private static boolean isEmptyItem(ItemStack it) {
        return it == null || it.getType().isAir();
    }

    // ================================================================ trader

    public ItemStack createTrader() {
        ItemStack item = new ItemStack(Material.NETHER_STAR);
        ItemMeta meta = item.getItemMeta();
        meta.displayName(Component.text("Gem Trader", NamedTextColor.GOLD)
                .decoration(TextDecoration.ITALIC, false));
        meta.lore(List.of(Component.text("Right-click to roll a new gem.", NamedTextColor.GRAY)
                        .decoration(TextDecoration.ITALIC, false),
                Component.text("Consumed on use.", NamedTextColor.GRAY)
                        .decoration(TextDecoration.ITALIC, false)));
        meta.setEnchantmentGlintOverride(true);
        meta.getPersistentDataContainer().set(traderKey, PersistentDataType.BYTE, (byte) 1);
        item.setItemMeta(meta);
        return item;
    }

    public boolean isTrader(ItemStack item) {
        return item != null && item.getType() == Material.NETHER_STAR && item.hasItemMeta()
                && item.getItemMeta().getPersistentDataContainer().has(traderKey, PersistentDataType.BYTE);
    }

    /** Removes one Gem Trader from the player's inventory. Returns false if they have none. */
    public boolean consumeTrader(Player player) {
        ItemStack[] contents = player.getInventory().getContents();
        for (int i = 0; i < contents.length; i++) {
            ItemStack it = contents[i];
            if (isTrader(it)) {
                if (it.getAmount() <= 1) {
                    player.getInventory().setItem(i, null);
                } else {
                    it.setAmount(it.getAmount() - 1);
                }
                return true;
            }
        }
        return false;
    }

    // ================================================================ state

    public boolean isStarted() {
        return data.getBoolean("started", false);
    }

    public void setStarted(boolean started) {
        data.set("started", started);
        save();
    }

    /** Gems are on and this player's gem isn't broken. */
    public boolean usable(Player p) {
        return isStarted() && !plugin.energy().isBroken(p);
    }

    public boolean hasReceived(UUID uuid) {
        return data.contains("received." + uuid);
    }

    public boolean isFlightGranted(UUID id) {
        return data.getBoolean("flight." + id, false);
    }

    public void setFlightGranted(UUID id, boolean v) {
        data.set("flight." + id, v ? Boolean.TRUE : null);
        save();
    }

    /** Gives the player a gem after the configured delay (not instantly). */
    public void scheduleGive(Player player) {
        UUID uuid = player.getUniqueId();
        if (!isStarted() || hasReceived(uuid) || rolling.containsKey(uuid) || !pending.add(uuid)) return;
        long delayTicks = Math.max(0L, plugin.getConfig().getLong("assignment.delay-seconds", 60)) * 20L;
        Bukkit.getScheduler().runTaskLater(plugin, () -> {
            pending.remove(uuid);
            Player p = Bukkit.getPlayer(uuid);
            if (p != null && p.isOnline() && isStarted()) {
                giveRandomGem(p);
            }
        }, delayTicks);
    }

    // ================================================================ roll animation

    /** First-time handout: roll and receive a random gem. */
    public void giveRandomGem(Player player) {
        startRoll(player, false);
    }

    public boolean isRolling(Player p) {
        return rolling.containsKey(p.getUniqueId());
    }

    /** Gem Trader use: roll to a new random gem that replaces the one they hold. */
    public void startTrade(Player player) {
        if (!isStarted()) {
            player.sendMessage(Component.text("Gems haven't started yet.", NamedTextColor.RED));
            return;
        }
        if (isRolling(player)) return;
        if (plugin.energy().isBroken(player)) {
            player.sendMessage(Component.text("Your gem is broken. Traders can't be used.", NamedTextColor.RED));
            return;
        }
        if (findGemSlot(player) < 0) {
            player.sendMessage(Component.text("You don't have a gem to trade.", NamedTextColor.RED));
            return;
        }
        startRoll(player, true);
    }

    private int findGemSlot(Player p) {
        ItemStack[] contents = p.getInventory().getContents();
        for (int i = 0; i < contents.length; i++) {
            if (isGem(contents[i])) return i;
        }
        return -1;
    }

    private int reserveSlot(Player p) {
        PlayerInventory inv = p.getInventory();
        for (int s = 0; s < 36; s++) {
            if (isEmptyItem(inv.getItem(s))) return s; // hotbar first, then the rest
        }
        return -1;
    }

    private ItemStack cycleItem(GemType shown) {
        ItemStack it = createGem(shown);
        ItemMeta meta = it.getItemMeta();
        meta.getPersistentDataContainer().set(rollKey, PersistentDataType.BYTE, (byte) 1);
        it.setItemMeta(meta);
        return it;
    }

    /**
     * Casino-style animation: the gem in the player's hand cycles through every gem, slowing down
     * until it lands on the chosen one. Titles, sounds and particles show it too, so it works for
     * Java and Bedrock (Geyser) players.
     */
    private void startRoll(Player player, boolean trade) {
        UUID uuid = player.getUniqueId();
        if (!trade && hasReceived(uuid)) return;
        if (rolling.containsKey(uuid)) return;

        PlayerInventory inv = player.getInventory();
        int slot = trade ? findGemSlot(player) : reserveSlot(player);
        if (trade && slot < 0) return;

        GemType[] all = GemType.values();
        List<GemType> pool = new ArrayList<>(List.of(all));
        ItemStack original = null;
        if (trade) {
            original = inv.getItem(slot).clone();
            pool.remove(getGem(original)); // always a new gem
        }
        GemType targetType = pool.get(ThreadLocalRandom.current().nextInt(pool.size()));
        Roll roll = new Roll(targetType, trade, slot, original);
        rolling.put(uuid, roll);
        if (slot >= 0 && slot < 9) inv.setHeldItemSlot(slot); // so it's visibly in their hand

        int frames = 28;
        // Pick the start so that the final frame lands exactly on the chosen gem.
        int start = Math.floorMod(targetType.ordinal() - (frames - 1), all.length);
        playFrame(uuid, all, start, 0, frames, roll);
    }

    private void setCycle(Player p, Roll roll, GemType shown) {
        if (roll.slot < 0) return;
        PlayerInventory inv = p.getInventory();
        ItemStack cur = inv.getItem(roll.slot);
        if (isEmptyItem(cur) || isRollItem(cur) || (roll.trade && isGem(cur))) {
            inv.setItem(roll.slot, cycleItem(shown));
        }
    }

    private void playFrame(UUID uuid, GemType[] all, int start, int i, int frames, Roll roll) {
        // Stale task: the roll already finished early (player left) or was replaced.
        if (rolling.get(uuid) != roll) return;

        Player p = Bukkit.getPlayer(uuid);
        // If gems get stopped or reset mid-roll, cancel and put everything back.
        if (p == null || !p.isOnline() || !isStarted()) {
            rolling.remove(uuid);
            if (p != null) abortRoll(p, roll);
            return;
        }
        // Wait while dead instead of animating or awarding to a corpse.
        if (p.isDead()) {
            Bukkit.getScheduler().runTaskLater(plugin, () -> playFrame(uuid, all, start, i, frames, roll), 20L);
            return;
        }

        if (i == frames - 1) {
            rolling.remove(uuid);
            finishRoll(p, roll);
            return;
        }

        GemType shown = all[(start + i) % all.length];
        GemType prev = all[Math.floorMod(start + i - 1, all.length)];
        GemType next = all[(start + i + 1) % all.length];

        setCycle(p, roll, shown);
        p.showTitle(Title.title(
                Component.text(shown.displayName(), shown.color()),
                Component.text("<  " + prev.displayName() + "   |   " + next.displayName() + "  >",
                        NamedTextColor.DARK_GRAY),
                Title.Times.times(Duration.ZERO, Duration.ofMillis(400), Duration.ZERO)));
        // Ding with rising pitch, plus particles that match the gem currently shown.
        p.playSound(p.getLocation(), Sound.BLOCK_NOTE_BLOCK_BELL, 1.0f, 0.7f + i * 0.045f);
        burst(p, shown, 15);

        // Fast at first, then slows down like a slot machine.
        long delay = i < 14 ? 2 : i < 20 ? 3 : i < 24 ? 5 : 8;
        Bukkit.getScheduler().runTaskLater(plugin, () -> playFrame(uuid, all, start, i + 1, frames, roll), delay);
    }

    /** Undoes an unfinished roll: their real gem comes back, or the placeholder disappears. */
    private void abortRoll(Player p, Roll roll) {
        if (roll.slot < 0) return;
        PlayerInventory inv = p.getInventory();
        if (isRollItem(inv.getItem(roll.slot))) {
            inv.setItem(roll.slot, roll.trade ? roll.original : null);
        }
    }

    private void abortAllRolls() {
        for (Map.Entry<UUID, Roll> en : new ArrayList<>(rolling.entrySet())) {
            Player p = Bukkit.getPlayer(en.getKey());
            if (p != null) abortRoll(p, en.getValue());
        }
        rolling.clear();
    }

    /** Gives a player the result of an unfinished roll right now (they left, or the server is stopping). */
    public void finishNow(Player p) {
        Roll roll = rolling.remove(p.getUniqueId());
        if (roll == null) return;
        if (!isStarted() || (!roll.trade && hasReceived(p.getUniqueId()))) {
            abortRoll(p, roll);
            return;
        }
        finishRoll(p, roll);
    }

    public void finishAll() {
        for (Player p : Bukkit.getOnlinePlayers()) finishNow(p);
    }

    /** A player died mid-roll: cancel it cleanly so no placeholder gem or lost gem is left behind. */
    public void abortOnDeath(PlayerDeathEvent e) {
        Player p = e.getEntity();
        Roll roll = rolling.remove(p.getUniqueId());
        if (roll == null) return;
        if (e.getKeepInventory()) {
            abortRoll(p, roll);
        } else {
            e.getDrops().removeIf(this::isRollItem);
            e.getItemsToKeep().removeIf(this::isRollItem);
            if (roll.trade && roll.original != null) e.getDrops().add(roll.original);
        }
        if (!roll.trade) scheduleGive(p); // first-time roll: try again later
    }

    /** Lands the roll: puts the final gem where the cycling one was and records it. */
    private void finishRoll(Player p, Roll roll) {
        if (roll.trade && !consumeTrader(p)) {
            abortRoll(p, roll);
            p.sendMessage(Component.text("Trade cancelled.", NamedTextColor.RED));
            return;
        }

        ItemStack gem = createGem(roll.target, p);
        PlayerInventory inv = p.getInventory();
        ItemStack cur = roll.slot >= 0 ? inv.getItem(roll.slot) : null;
        if (roll.slot >= 0 && (isEmptyItem(cur) || isRollItem(cur))) {
            inv.setItem(roll.slot, gem);
        } else {
            if (roll.trade) {
                int old = findGemSlot(p);
                if (old >= 0) inv.setItem(old, null);
            }
            inv.addItem(gem).values().forEach(i -> p.getWorld().dropItemNaturally(p.getLocation(), i));
        }

        data.set("received." + p.getUniqueId(), roll.target.name());
        save();
        celebrate(p, roll.target);
        if (roll.trade) plugin.advancements().award(p, "change");
    }

    private void burst(Player p, GemType type, int count) {
        p.getWorld().spawnParticle(type.particle(), p.getLocation().add(0, 1.0, 0),
                count, 0.6, 0.8, 0.6, 0.02);
    }

    private void celebrate(Player player, GemType type) {
        player.showTitle(Title.title(
                Component.text(type.displayName() + " Gem", type.color()),
                Component.text("is yours!", NamedTextColor.WHITE),
                Title.Times.times(Duration.ZERO, Duration.ofSeconds(3), Duration.ofSeconds(1))));
        burst(player, type, 60);
        player.playSound(player.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 1.0f, 1.0f);
        player.playSound(player.getLocation(), Sound.UI_TOAST_CHALLENGE_COMPLETE, 1.0f, 1.0f);

        String msg = plugin.getConfig().getString("assignment.message", "&aYou received the &f%gem% &agem!")
                .replace("%gem%", type.displayName());
        player.sendMessage(LegacyComponentSerializer.legacyAmpersand().deserialize(msg));
    }

    // ================================================================ reset / cleanup

    /**
     * Removes gems left over from before a reset, and cleans up animation items left by a crash
     * (their recorded gem is put back if they had one).
     */
    public int purgeStale(Player p) {
        PlayerInventory inv = p.getInventory();
        ItemStack[] contents = inv.getContents();
        boolean live = rolling.containsKey(p.getUniqueId());
        String rec = data.getString("received." + p.getUniqueId());
        boolean restored = false;
        int removed = 0;
        for (int i = 0; i < contents.length; i++) {
            ItemStack it = contents[i];
            if (isRollItem(it)) {
                if (live) continue;
                if (rec != null && !restored) {
                    try {
                        inv.setItem(i, createGem(GemType.valueOf(rec), p));
                        restored = true;
                    } catch (IllegalArgumentException ex) {
                        inv.setItem(i, null);
                    }
                } else {
                    inv.setItem(i, null);
                }
                removed++;
            } else if (isStaleGem(it)) {
                inv.setItem(i, null);
                removed++;
            }
        }
        if (isStaleGem(p.getItemOnCursor())) {
            p.setItemOnCursor(null);
            removed++;
        }
        return removed;
    }

    /**
     * Back to how it was before /bliss start: gems off, nobody has received one, and every gem
     * that exists is invalidated. Offline players lose theirs when they next join.
     */
    public void reset() {
        abortAllRolls();
        generation++;
        data.set("generation", generation);
        data.set("received", null);
        data.set("started", false);
        save();
        pending.clear();
        for (Player p : Bukkit.getOnlinePlayers()) purgeStale(p);
    }

    private void save() {
        try {
            data.save(dataFile);
        } catch (IOException e) {
            plugin.getLogger().severe("Could not save data.yml: " + e.getMessage());
        }
    }
}
