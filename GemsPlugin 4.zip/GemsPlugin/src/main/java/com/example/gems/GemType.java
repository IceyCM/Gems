package com.example.gems;

import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Material;
import org.bukkit.Particle;

public enum GemType {
    SPEED(Material.SUGAR, NamedTextColor.AQUA, Particle.CLOUD),
    STRENGTH(Material.BLAZE_POWDER, NamedTextColor.DARK_RED, Particle.ANGRY_VILLAGER),
    FIRE(Material.MAGMA_CREAM, NamedTextColor.GOLD, Particle.FLAME),
    LIFE(Material.GHAST_TEAR, NamedTextColor.LIGHT_PURPLE, Particle.HEART),
    PUFF(Material.FEATHER, NamedTextColor.WHITE, Particle.POOF),
    ASTRA(Material.AMETHYST_SHARD, NamedTextColor.DARK_PURPLE, Particle.END_ROD),
    TOMB(Material.BONE, NamedTextColor.GRAY, Particle.SOUL),
    TIDE(Material.PRISMARINE_SHARD, NamedTextColor.BLUE, Particle.SPLASH),
    CRIMSON(Material.NETHER_WART, NamedTextColor.RED, Particle.CRIMSON_SPORE),
    SPRING(Material.SLIME_BALL, NamedTextColor.GREEN, Particle.HAPPY_VILLAGER),
    WEALTH(Material.EMERALD, NamedTextColor.YELLOW, Particle.TOTEM_OF_UNDYING),
    FROST(Material.PACKED_ICE, NamedTextColor.DARK_AQUA, Particle.SNOWFLAKE);

    private final Material material;
    private final NamedTextColor color;
    private final Particle particle;

    GemType(Material material, NamedTextColor color, Particle particle) {
        this.material = material;
        this.color = color;
        this.particle = particle;
    }

    public Material material() { return material; }
    public NamedTextColor color() { return color; }
    public Particle particle() { return particle; }

    public String displayName() {
        return name().charAt(0) + name().substring(1).toLowerCase();
    }
}
