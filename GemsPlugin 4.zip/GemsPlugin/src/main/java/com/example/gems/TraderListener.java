package com.example.gems;

import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.EquipmentSlot;

/** Right-clicking with a Gem Trader rolls the player a brand new gem. */
public class TraderListener implements Listener {

    private final GemsPlugin plugin;

    public TraderListener(GemsPlugin plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onUse(PlayerInteractEvent e) {
        if (e.getHand() != EquipmentSlot.HAND) return;
        if (e.getAction() != Action.RIGHT_CLICK_AIR && e.getAction() != Action.RIGHT_CLICK_BLOCK) return;
        if (!plugin.gems().isTrader(e.getItem())) return;

        e.setCancelled(true);
        plugin.gems().startTrade(e.getPlayer());
    }
}
