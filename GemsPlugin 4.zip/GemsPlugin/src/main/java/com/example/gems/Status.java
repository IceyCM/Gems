package com.example.gems;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.Event;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.event.player.PlayerQuitEvent;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/** Shared stun and cobweb-lock effects used by several gems. */
public class Status implements Listener {

    private final Map<UUID, Long> stun = new HashMap<>();
    private final Map<UUID, Long> web = new HashMap<>();

    private static long now() { return System.currentTimeMillis(); }

    public void stun(Player p, long ms) {
        if (p == null) return;
        stun.merge(p.getUniqueId(), now() + ms, Math::max);
    }

    public boolean isStunned(Player p) {
        Long t = stun.get(p.getUniqueId());
        if (t == null) return false;
        if (t <= now()) {
            stun.remove(p.getUniqueId());
            return false;
        }
        return true;
    }

    public void webLock(Player p, long ms) {
        web.merge(p.getUniqueId(), now() + ms, Math::max);
    }

    public boolean webLocked(Player p) {
        Long t = web.get(p.getUniqueId());
        if (t == null) return false;
        if (t <= now()) {
            web.remove(p.getUniqueId());
            return false;
        }
        return true;
    }

    public void clearAll() {
        stun.clear();
        web.clear();
    }

    // A stunned player can't walk (they can still look around and fall).
    @EventHandler(ignoreCancelled = true)
    public void onMove(PlayerMoveEvent e) {
        if (stun.isEmpty() || !isStunned(e.getPlayer())) return;
        Location from = e.getFrom();
        Location to = e.getTo();
        if (to == null) return;
        if (from.getX() != to.getX() || from.getZ() != to.getZ()) {
            to.setX(from.getX());
            to.setZ(from.getZ());
            e.setTo(to);
        }
    }

    // ...and can't attack or use items.
    @EventHandler(priority = EventPriority.LOWEST, ignoreCancelled = true)
    public void onAttack(EntityDamageByEntityEvent e) {
        if (!stun.isEmpty() && e.getDamager() instanceof Player p && isStunned(p)) e.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.LOWEST)
    public void onInteract(PlayerInteractEvent e) {
        Action a = e.getAction();
        if (a != Action.RIGHT_CLICK_AIR && a != Action.RIGHT_CLICK_BLOCK && a != Action.LEFT_CLICK_AIR
                && a != Action.LEFT_CLICK_BLOCK) return;
        Player p = e.getPlayer();
        if (!stun.isEmpty() && isStunned(p)) {
            e.setUseItemInHand(Event.Result.DENY);
            return;
        }
        if (!web.isEmpty() && webLocked(p) && e.getItem() != null && e.getItem().getType() == Material.COBWEB) {
            e.setUseItemInHand(Event.Result.DENY);
            p.sendActionBar(Component.text("Your cobwebs are disabled.", NamedTextColor.RED));
        }
    }

    @EventHandler(ignoreCancelled = true)
    public void onPlace(BlockPlaceEvent e) {
        if (!web.isEmpty() && e.getBlockPlaced().getType() == Material.COBWEB && webLocked(e.getPlayer())) {
            e.setCancelled(true);
        }
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        stun.remove(e.getPlayer().getUniqueId());
        web.remove(e.getPlayer().getUniqueId());
    }

    @EventHandler
    public void onDeath(PlayerDeathEvent e) {
        stun.remove(e.getEntity().getUniqueId());
        web.remove(e.getEntity().getUniqueId());
    }
}
