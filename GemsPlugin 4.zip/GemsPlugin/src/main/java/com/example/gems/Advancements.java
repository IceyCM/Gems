package com.example.gems;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Bukkit;
import org.bukkit.NamespacedKey;
import org.bukkit.advancement.Advancement;
import org.bukkit.advancement.AdvancementProgress;
import org.bukkit.entity.Player;

import java.util.HashMap;
import java.util.Map;

/**
 * Registers the gem advancements through Paper's unsafe API. If that ever fails on a future version,
 * players still get a chat message instead.
 */
@SuppressWarnings("deprecation")
public class Advancements {

    private static final String[][] DEFS = {
            // id, icon, title, description, frame
            {"shattered", "minecraft:amethyst_shard", "Shattered", "Your gem has broken.", "challenge"},
            {"change", "minecraft:nether_star", "Time for a change", "Trade your gem for a new one.", "task"},
            {"overcharged", "minecraft:end_crystal", "Overcharged", "Push your gem to Pristine +5.", "challenge"},
    };

    private final GemsPlugin plugin;
    private final Map<String, Advancement> loaded = new HashMap<>();
    private final Map<String, String> titles = new HashMap<>();
    private Advancement root;

    public Advancements(GemsPlugin plugin) {
        this.plugin = plugin;
    }

    public void register() {
        try {
            root = load("root", json(null, "minecraft:amethyst_shard", "Gems", "The gem system.", "task",
                    false, false, "minecraft:textures/gui/advancements/backgrounds/stone.png"));
            for (String[] d : DEFS) {
                titles.put(d[0], d[2]);
                loaded.put(d[0], load(d[0], json(plugin.getName().toLowerCase() + ":root", d[1], d[2], d[3], d[4],
                        true, true, null)));
            }
        } catch (Exception | LinkageError ex) {
            plugin.getLogger().warning("Could not register advancements (" + ex.getMessage()
                    + "). Players will get a chat message instead.");
            loaded.clear();
            root = null;
        }
    }

    private Advancement load(String id, String json) {
        NamespacedKey key = new NamespacedKey(plugin, id);
        Advancement existing = Bukkit.getAdvancement(key);
        if (existing != null) return existing;
        return Bukkit.getUnsafe().loadAdvancement(key, json);
    }

    private static String json(String parent, String icon, String title, String desc, String frame,
                               boolean toast, boolean chat, String background) {
        StringBuilder sb = new StringBuilder("{");
        if (parent != null) sb.append("\"parent\":\"").append(parent).append("\",");
        sb.append("\"display\":{");
        sb.append("\"icon\":{\"id\":\"").append(icon).append("\"},");
        sb.append("\"title\":{\"text\":\"").append(title).append("\"},");
        sb.append("\"description\":{\"text\":\"").append(desc).append("\"},");
        if (background != null) sb.append("\"background\":\"").append(background).append("\",");
        sb.append("\"frame\":\"").append(frame).append("\",");
        sb.append("\"show_toast\":").append(toast).append(",");
        sb.append("\"announce_to_chat\":").append(chat).append(",");
        sb.append("\"hidden\":false},");
        sb.append("\"criteria\":{\"done\":{\"trigger\":\"minecraft:impossible\"}}}");
        return sb.toString();
    }

    /** Gives the advancement to an online player (once). */
    public void award(Player p, String id) {
        Advancement adv = loaded.get(id);
        if (adv == null) {
            String title = titles.getOrDefault(id, id);
            p.sendMessage(Component.text(p.getName() + " has made the advancement [" + title + "]",
                    NamedTextColor.GREEN));
            return;
        }
        try {
            if (root != null) {
                AdvancementProgress rp = p.getAdvancementProgress(root);
                if (!rp.isDone()) rp.awardCriteria("done");
            }
            AdvancementProgress pr = p.getAdvancementProgress(adv);
            if (!pr.isDone()) pr.awardCriteria("done");
        } catch (Exception ex) {
            plugin.getLogger().warning("Could not award advancement " + id + ": " + ex.getMessage());
        }
    }
}
