package com.example.gems;

import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.player.PlayerQuitEvent;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/** Remembers which gem ability last hurt a player, for custom death messages and kill credit. */
public class Deaths implements Listener {

    private record Cause(UUID killer, String key, long at) {}

    private final GemsPlugin plugin;
    private final Map<UUID, Cause> map = new HashMap<>();

    public Deaths(GemsPlugin plugin) {
        this.plugin = plugin;
    }

    public void record(UUID victim, UUID killer, String key) {
        map.put(victim, new Cause(killer, key, System.currentTimeMillis()));
    }

    private Cause fresh(UUID victim) {
        Cause c = map.get(victim);
        if (c == null) return null;
        long window = (long) (plugin.getConfig().getDouble("deaths.window-seconds", 3.0) * 1000.0);
        return System.currentTimeMillis() - c.at() <= window ? c : null;
    }

    /** The player who gets credit for this death: a recent ability hit, else the vanilla killer. */
    public Player killerOf(Player victim) {
        Cause c = fresh(victim.getUniqueId());
        if (c != null) {
            Player k = Bukkit.getPlayer(c.killer());
            if (k != null && !k.equals(victim)) return k;
        }
        Player k = victim.getKiller();
        return (k != null && !k.equals(victim)) ? k : null;
    }

    @EventHandler(priority = EventPriority.HIGH)
    public void onDeath(PlayerDeathEvent e) {
        Player victim = e.getEntity();
        Cause c = fresh(victim.getUniqueId());
        if (c == null) return;
        Player killer = Bukkit.getPlayer(c.killer());
        if (killer == null || killer.equals(victim)) return;
        String template = plugin.getConfig().getString("deaths." + c.key());
        if (template == null || template.isBlank()) return;
        e.deathMessage(Component.text(template
                .replace("%victim%", victim.getName())
                .replace("%killer%", killer.getName())));
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        map.remove(e.getPlayer().getUniqueId());
    }
}
