package com.example.gems;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.*;
import org.bukkit.entity.*;
import org.bukkit.event.*;
import org.bukkit.event.block.Action;
import org.bukkit.event.entity.*;
import org.bukkit.event.player.*;
import org.bukkit.potion.*;
import org.bukkit.scheduler.BukkitTask;
import org.bukkit.util.Vector;

import java.util.*;

public class SpeedGem implements Listener {

    private final GemsPlugin plugin;
    private final GemManager gems;
    private final Cooldowns cd;
    private final Status status;
    private final Deaths deaths;

    private final Map<UUID, Long> recallTarget = new HashMap<>();
    private final Map<UUID, UUID> recallCaster = new HashMap<>();
    private final Map<UUID, Long> blurActive = new HashMap<>();
    private final Map<UUID, UUID> blurVictim = new HashMap<>();
    private final Map<UUID, Integer> blurHits = new HashMap<>();
    private final Map<UUID, Long> overdriveUntil = new HashMap<>();
    private final Map<UUID, Long> swordHits = new HashMap<>(); // stores hit counts in upper bits
    private final Map<UUID, Integer> elecHits = new HashMap<>();
    private final Map<UUID, Integer> tempoHits = new HashMap<>();
    private final Map<UUID, Long> sneakStart = new HashMap<>();
    private final Set<UUID> windBlock = new HashSet<>();
    private final Map<UUID, Long> windBlockUntil = new HashMap<>();
    private int internal = 0;

    private static final String[] KEYS = {"recall","speedy","blur","dazzle","overdrive"};
    private static final double[] CDS = {120,90,100,70,120};

    public SpeedGem(GemsPlugin plugin) {
        this.plugin = plugin;
        this.gems = plugin.gems();
        this.cd = plugin.cooldowns();
        this.status = plugin.status();
        this.deaths = plugin.deaths();
    }

    public void start() {
        Bukkit.getScheduler().runTaskTimer(plugin, this::tick, 1L, 1L);
    }

    private boolean hasSpeed(Player p) { return gems.getGem(p.getInventory().getItemInMainHand()) == GemType.SPEED || gems.getGem(p.getInventory().getItemInOffHand()) == GemType.SPEED; }
    private boolean turbo(Player p) { return p.getWorld().hasStorm(); }
    private boolean thunder(Player p) { return p.getWorld().isThundering(); }
    private double d(String k, double def) { return plugin.getConfig().getDouble("speed."+k,def); }
    private long ms(String k, double def) { return (long)(d(k,def)*1000); }
    private int tks(String k, double def) { return (int)Math.max(1,d(k,def)*20); }
    private static long now() { return System.currentTimeMillis(); }
    private void bar(Player p, String msg, NamedTextColor c) { p.sendActionBar(Component.text(msg,c)); }

    private void hurt(LivingEntity t, double hearts, Player src, String deathKey) {
        if (t.equals(src)) return;
        internal++;
        try {
            t.setNoDamageTicks(0);
            t.setHealth(Math.max(0, t.getHealth() - hearts*2.0));
            if (t.getHealth() <= 0 && t instanceof Player v) deaths.record(v.getUniqueId(), src.getUniqueId(), deathKey);
        } finally { internal--; }
    }

    private void lightning(Location loc, Player src, double hearts, String key) {
        loc.getWorld().strikeLightningEffect(loc);
        for (Entity en : loc.getWorld().getNearbyEntities(loc, 1,1,1)) {
            if (en instanceof LivingEntity le && !le.equals(src)) hurt(le, hearts, src, key);
        }
    }

    private long cdFactor(Player p) {
        double f = plugin.energy().cooldownFactor(p) * (thunder(p) ? 0.5 : 1.0);
        return (long)(f * 1000);
    }

    private void startCd(Player p, int idx) {
        cd.start(p.getUniqueId(), "spd_"+KEYS[idx], (long)(CDS[idx] * plugin.energy().cooldownFactor(p) * (thunder(p)?0.5:1.0) * 1000));
    }

    public void activate(Player p, int idx) {
        if (!gems.usable(p)) return;
        String key = "spd_"+KEYS[idx];
        long left = cd.remainingMs(p.getUniqueId(), key);
        if (left > 0) { bar(p, Abilities.names(GemType.SPEED).get(idx)+" on cooldown: "+Cooldowns.format(left), NamedTextColor.RED); return; }
        switch(idx) {
            case 0 -> staticRecall(p);
            case 1 -> speedyBoi(p);
            case 2 -> blur(p);
            case 3 -> dazzlingStun(p);
            case 4 -> overdrive(p);
        }
    }

    private void staticRecall(Player p) {
        Player t = nearest(p, d("recall.radius",5.0) * plugin.energy().reachFactor(p));
        if (t == null) { bar(p,"No target in range.",NamedTextColor.GRAY); return; }
        recallTarget.put(t.getUniqueId(), now() + ms("recall.delay-seconds",10.0));
        recallCaster.put(t.getUniqueId(), p.getUniqueId());
        lightning(t.getLocation(), p, d("recall.initial-hearts",2.0), "speed.recall");
        t.sendMessage(Component.text("You have been tagged! You will be recalled in 10 seconds.", NamedTextColor.RED));
        bar(p,"Static Recall tagged "+t.getName()+"!", NamedTextColor.YELLOW);
        startCd(p,0);
    }

    private void speedyBoi(Player p) {
        boolean tb = turbo(p);
        int dur = tks(tb?"speedy.turbo-seconds":"speedy.duration-seconds", tb?22:15);
        p.addPotionEffect(new PotionEffect(PotionEffectType.SPEED,dur,2));
        p.addPotionEffect(new PotionEffect(PotionEffectType.HASTE,dur,4));
        p.addPotionEffect(new PotionEffect(PotionEffectType.REGENERATION,dur,2));
        bar(p,"Speedy Boi!", NamedTextColor.YELLOW);
        startCd(p,1);
    }

    private void blur(Player p) {
        blurActive.put(p.getUniqueId(), now() + ms("blur.duration-seconds",15.0));
        blurVictim.remove(p.getUniqueId());
        blurHits.put(p.getUniqueId(), 0);
        bar(p,"Blur ready! Hit a player 3 times.", NamedTextColor.YELLOW);
        startCd(p,2);
    }

    private void dazzlingStun(Player p) {
        double r = d("dazzle.radius",6.0)*plugin.energy().reachFactor(p);
        List<Player> near = new ArrayList<>(p.getWorld().getNearbyPlayers(p.getLocation(),r));
        near.remove(p); near.sort(Comparator.comparingDouble(o->o.getLocation().distanceSquared(p.getLocation())));
        List<Player> targets = near.subList(0, Math.min(3, near.size()));
        for (Player t : targets) {
            lightning(t.getLocation(), p, d("dazzle.damage-hearts",2.5), "speed.dazzle");
            t.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS,tks("dazzle.slow-seconds",9.0),254));
            t.addPotionEffect(new PotionEffect(PotionEffectType.MINING_FATIGUE,tks("dazzle.slow-seconds",9.0),1));
        }
        bar(p,"Dazzling Stun!", NamedTextColor.YELLOW);
        startCd(p,3);
    }

    private void overdrive(Player p) {
        overdriveUntil.put(p.getUniqueId(), now() + ms("overdrive.duration-seconds",30.0));
        swordHits.put(p.getUniqueId(), 0L);
        bar(p,"Overdrive!", NamedTextColor.YELLOW);
        startCd(p,4);
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onHit(EntityDamageByEntityEvent e) {
        if (internal > 0 || !(e.getDamager() instanceof Player a) || !(e.getEntity() instanceof LivingEntity t)) return;
        if (!hasSpeed(a) || !gems.usable(a)) return;
        boolean tb = turbo(a);
        boolean isCrit = a.getFallDistance()>0 && !a.isOnGround() && !a.isInWater() && a.getAttackCooldown()>0.848f;
        boolean sword = a.getInventory().getItemInMainHand().getType().name().endsWith("_SWORD");
        boolean axe = a.getInventory().getItemInMainHand().getType().name().endsWith("_AXE");
        UUID id = a.getUniqueId();

        // Electrical charge
        if (sword) {
            int eh = elecHits.merge(id,1,Integer::sum);
            int thr = tb ? plugin.getConfig().getInt("speed.elec.turbo-hits",10) : plugin.getConfig().getInt("speed.elec.hits",16);
            if (eh >= thr) {
                elecHits.put(id,0);
                if (t instanceof Player pt) lightning(pt.getLocation(), a, d("elec.damage-hearts",1.5), "speed.elec");
                status.stun(t instanceof Player pt ? pt : null, 200L);
            }
        }
        // Temporal pause
        if (axe) {
            int th = tempoHits.merge(id,1,Integer::sum);
            int thr = tb ? plugin.getConfig().getInt("speed.tempo.turbo-hits",8) : plugin.getConfig().getInt("speed.tempo.hits",13);
            if (th >= thr) {
                tempoHits.put(id,0);
                if (t instanceof Player pt) {
                    double dmg = tb ? d("tempo.turbo-hearts",3.0) : d("tempo.hearts",2.0);
                    int slow = tb ? tks("tempo.turbo-slow-seconds",5.0) : tks("tempo.slow-seconds",4.0);
                    lightning(pt.getLocation(), a, dmg, "speed.tempo");
                    pt.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS, slow, 254));
                }
            }
        }
        // Overdrive
        if (sword) {
            Long od = overdriveUntil.get(id);
            if (od != null && od > now()) {
                long hits = swordHits.getOrDefault(id, 0L) + (isCrit ? 2 : 1);
                swordHits.put(id, hits);
                int need = tb ? plugin.getConfig().getInt("speed.overdrive.turbo-hits",4) : plugin.getConfig().getInt("speed.overdrive.hits",5);
                if (hits >= need) {
                    swordHits.put(id, 0L);
                    double dmg = d("overdrive.damage-hearts",2.0) + Math.random()*d("overdrive.damage-range",1.0);
                    if (t instanceof Player pt) lightning(pt.getLocation(), a, dmg, "speed.overdrive");
                }
            }
        }
        // Blur
        Long blurEnd = blurActive.get(id);
        if (blurEnd != null && blurEnd > now() && t instanceof Player victim) {
            UUID vid = victim.getUniqueId();
            UUID existing = blurVictim.get(id);
            if (existing == null) {
                int bh = blurHits.merge(id,1,Integer::sum);
                if (bh >= 3) { blurVictim.put(id, vid); blurHits.put(id,0); bar(a,"Blur tagged "+victim.getName()+"!",NamedTextColor.YELLOW); }
            } else if (existing.equals(vid)) {
                boolean turboBlur = turbo(a);
                double blurDmg = turboBlur ? d("blur.turbo-hearts",2.0) : d("blur.hearts",1.5);
                for (int s = 0; s < 3; s++) {
                    double angle = (s * 120.0) * Math.PI / 180.0;
                    Location l = victim.getLocation().add(Math.cos(angle)*1.5,0,Math.sin(angle)*1.5);
                    lightning(l, a, blurDmg/3.0, "speed.blur");
                }
                victim.setVelocity(victim.getVelocity().add(new Vector(0,0.4,0)));
                if (turboBlur) {
                    long end = now() + ms("blur.turbo-duration-seconds",25.0);
                    if (!blurActive.containsKey(id) || blurActive.get(id) < end) blurActive.put(id,end);
                }
            }
        }
    }

    private Player nearest(Player p, double r) {
        Player best=null; double bd=Double.MAX_VALUE;
        for (Player o : p.getWorld().getNearbyPlayers(p.getLocation(),r)) {
            if (o.equals(p)||o.isDead()||o.getGameMode()==GameMode.SPECTATOR) continue;
            double d=o.getLocation().distanceSquared(p.getLocation());
            if (d<bd){bd=d;best=o;}
        }
        return best;
    }

    @EventHandler
    public void onSneak(PlayerToggleSneakEvent e) {
        UUID id = e.getPlayer().getUniqueId();
        if (e.isSneaking()) sneakStart.put(id,now()); else sneakStart.remove(id);
    }

    private void tryEnchantTool(Player p) {
        if (!hasSpeed(p)||!gems.usable(p)) return;
        UUID id=p.getUniqueId();
        if (cd.remainingMs(id,"spd_sharp")>0) return;
        org.bukkit.inventory.ItemStack off=p.getInventory().getItemInOffHand();
        if (off==null||off.getType().isAir()){bar(p,"Hold a tool in offhand.",NamedTextColor.GRAY);return;}
        String n=off.getType().name();
        boolean tool=n.endsWith("_PICKAXE")||n.endsWith("_AXE")||n.endsWith("_SHOVEL")||n.endsWith("_HOE")||n.endsWith("_SWORD");
        if (!tool){bar(p,"Hold a tool or weapon in offhand.",NamedTextColor.GRAY);return;}
        int lvl=plugin.getConfig().getInt("speed.efficiency.level",5);
        if (off.getItemMeta().getEnchantLevel(org.bukkit.enchantments.Enchantment.EFFICIENCY)>=lvl){bar(p,"Already has Efficiency "+lvl+".",NamedTextColor.GRAY);return;}
        org.bukkit.inventory.meta.ItemMeta meta=off.getItemMeta();
        meta.addEnchant(org.bukkit.enchantments.Enchantment.EFFICIENCY,lvl,true);
        off.setItemMeta(meta);
        p.getInventory().setItemInOffHand(off);
        cd.start(id,"spd_sharp",ms("efficiency.cooldown-seconds",180.0));
        bar(p,"Efficiency "+lvl+" applied!",NamedTextColor.YELLOW);
        p.playSound(p.getLocation(),Sound.BLOCK_ENCHANTMENT_TABLE_USE,1,1);
    }

    private void tick() {
        long now=now();
        // alternating speed passive
        for (Player p : Bukkit.getOnlinePlayers()) {
            if (!hasSpeed(p)||!gems.usable(p)||gems.isRolling(p)) continue;
            long t=now/1000;
            int amp=(t%2==0)?0:1;
            PotionEffect cur=p.getPotionEffect(PotionEffectType.SPEED);
            if (cur==null||cur.getAmplifier()!=amp||cur.getDuration()<10)
                p.addPotionEffect(new PotionEffect(PotionEffectType.SPEED,20,amp,true,false,true));
            // sneak enchant
            Long ss=sneakStart.get(p.getUniqueId());
            if (ss!=null&&now-ss>=ms("efficiency.sneak-seconds",1.0)) {
                sneakStart.remove(p.getUniqueId()); tryEnchantTool(p);
            }
        }
        // Static Recall pull
        recallTarget.entrySet().removeIf(en -> {
            if (en.getValue()>now) return false;
            Player t=Bukkit.getPlayer(en.getKey());
            UUID cid=recallCaster.remove(en.getKey());
            Player caster=cid!=null?Bukkit.getPlayer(cid):null;
            if (t!=null&&caster!=null&&t.isOnline()&&caster.isOnline()) {
                t.teleport(caster.getLocation());
                lightning(t.getLocation(),caster,d("recall.final-hearts",3.0),"speed.recall");
                boolean tb=turbo(caster);
                if (tb) { status.stun(t,ms("recall.turbo-stun-seconds",4.0)); windBlockUntil.put(t.getUniqueId(),now+ms("recall.web-seconds",5.0)); }
                else t.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS,tks("recall.slow-seconds",3.0),254));
            }
            return true;
        });
        // blur expiry
        blurActive.entrySet().removeIf(en -> {
            if (en.getValue()>now) return false;
            blurVictim.remove(en.getKey()); blurHits.remove(en.getKey()); return true;
        });
        overdriveUntil.entrySet().removeIf(en->en.getValue()<=now);
        windBlockUntil.entrySet().removeIf(en->en.getValue()<=now);
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        UUID id=e.getPlayer().getUniqueId();
        recallTarget.remove(id); recallCaster.remove(id);
        blurActive.remove(id); blurVictim.remove(id); blurHits.remove(id);
        overdriveUntil.remove(id); swordHits.remove(id);
        elecHits.remove(id); tempoHits.remove(id);
        sneakStart.remove(id); windBlockUntil.remove(id);
    }

    @EventHandler
    public void onDeath(PlayerDeathEvent e) {
        UUID id=e.getEntity().getUniqueId();
        recallTarget.remove(id); recallCaster.remove(id);
        blurActive.remove(id); blurVictim.remove(id);
        overdriveUntil.remove(id); sneakStart.remove(id);
    }
}
