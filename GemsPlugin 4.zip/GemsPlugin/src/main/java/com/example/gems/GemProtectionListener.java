package com.example.gems;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Item;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.inventory.ClickType;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.inventory.InventoryCreativeEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.inventory.InventoryType;
import org.bukkit.event.inventory.PrepareItemCraftEvent;
import org.bukkit.event.player.PlayerArmorStandManipulateEvent;
import org.bukkit.event.player.PlayerDropItemEvent;
import org.bukkit.event.player.PlayerInteractEntityEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerSwapHandItemsEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;
import org.bukkit.inventory.meta.BundleMeta;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/** Keeps gems from leaving a player's inventory. */
public class GemProtectionListener implements Listener {

    private final GemsPlugin plugin;

    public GemProtectionListener(GemsPlugin plugin) {
        this.plugin = plugin;
    }

    private boolean isGem(ItemStack item) {
        return plugin.gems().isGem(item);
    }

    private static boolean isBundle(ItemStack item) {
        return item != null && item.getType().name().endsWith("BUNDLE");
    }

    // ---- Everything is frozen while a player is rolling a gem ----

    private boolean rolling(Player p) {
        return plugin.gems().isRolling(p);
    }

    @EventHandler(priority = EventPriority.LOWEST, ignoreCancelled = true)
    public void freezeClick(InventoryClickEvent e) {
        if (e.getWhoClicked() instanceof Player p && rolling(p)) e.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.LOWEST, ignoreCancelled = true)
    public void freezeDrag(InventoryDragEvent e) {
        if (e.getWhoClicked() instanceof Player p && rolling(p)) e.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.LOWEST, ignoreCancelled = true)
    public void freezeCreative(InventoryCreativeEvent e) {
        if (e.getWhoClicked() instanceof Player p && rolling(p)) e.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.LOWEST, ignoreCancelled = true)
    public void freezeDrop(PlayerDropItemEvent e) {
        if (rolling(e.getPlayer())) e.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.LOWEST, ignoreCancelled = true)
    public void freezeSwap(PlayerSwapHandItemsEvent e) {
        if (rolling(e.getPlayer())) e.setCancelled(true);
    }

    // Gems can never be dropped.
    @EventHandler(ignoreCancelled = true)
    public void onDrop(PlayerDropItemEvent e) {
        if (isGem(e.getItemDrop().getItemStack())) {
            e.setCancelled(true);
            e.getPlayer().sendMessage(Component.text("Gems can't be dropped.", NamedTextColor.RED));
        }
    }

    // Stop gems being moved into chests, ender chests, villager trades, crafting grids, bundles, etc.
    @EventHandler(ignoreCancelled = true)
    public void onClick(InventoryClickEvent e) {
        if (!(e.getWhoClicked() instanceof Player p)) return;

        ItemStack cursor = e.getCursor();
        ItemStack current = e.getCurrentItem();

        // Safety net: if a bundle is involved in any way, check bundles right after the click resolves.
        if (isBundle(cursor) || isBundle(current)) scheduleSweep(p);

        // Bundles would let a gem slip into a container.
        if ((isGem(cursor) && isBundle(current)) || (isBundle(cursor) && isGem(current))) {
            deny(e, p);
            return;
        }

        Inventory clicked = e.getClickedInventory();
        if (clicked == null) return;
        Inventory top = e.getView().getTopInventory();
        ClickType click = e.getClick();

        if (clicked.equals(top)) {
            boolean bad = isGem(cursor)
                    || (click == ClickType.NUMBER_KEY && e.getHotbarButton() >= 0
                        && isGem(p.getInventory().getItem(e.getHotbarButton())))
                    || (click == ClickType.SWAP_OFFHAND && isGem(p.getInventory().getItemInOffHand()));
            if (bad) deny(e, p);
        } else if (click.isShiftClick() && isGem(current) && top.getType() != InventoryType.CRAFTING) {
            // Shift-clicking inside your own inventory screen is fine; into any other screen is not.
            deny(e, p);
        }
    }

    private void deny(InventoryClickEvent e, Player p) {
        e.setCancelled(true);
        p.sendMessage(Component.text("Gems can't be stored or moved out of your inventory.", NamedTextColor.RED));
    }

    @EventHandler(ignoreCancelled = true)
    public void onDrag(InventoryDragEvent e) {
        if (e.getWhoClicked() instanceof Player p && isBundle(e.getOldCursor())) scheduleSweep(p);
        if (!isGem(e.getOldCursor())) return;
        int topSize = e.getView().getTopInventory().getSize();
        for (int slot : e.getRawSlots()) {
            if (slot < topSize) {
                e.setCancelled(true);
                return;
            }
        }
    }

    // A gem can't be handed to any entity: item frames, allays, wolves (bones), villagers (emeralds)...
    @EventHandler(ignoreCancelled = true)
    public void onInteractEntity(PlayerInteractEntityEvent e) {
        if (isGem(e.getPlayer().getInventory().getItem(e.getHand()))) e.setCancelled(true);
    }

    @EventHandler(ignoreCancelled = true)
    public void onArmorStand(PlayerArmorStandManipulateEvent e) {
        if (isGem(e.getPlayerItem())) e.setCancelled(true);
    }

    // Decorated pots accept any item.
    @EventHandler(ignoreCancelled = true)
    public void onInteractBlock(PlayerInteractEvent e) {
        if (e.getAction() != Action.RIGHT_CLICK_BLOCK || e.getClickedBlock() == null) return;
        if (e.getClickedBlock().getType() == Material.DECORATED_POT && isGem(e.getItem())) {
            e.setCancelled(true);
        }
    }

    // Some gem materials are blocks (nether wart, packed ice).
    @EventHandler(ignoreCancelled = true)
    public void onPlace(BlockPlaceEvent e) {
        if (isGem(e.getItemInHand())) e.setCancelled(true);
    }

    // Gems can't be used as crafting ingredients.
    @EventHandler
    public void onPrepareCraft(PrepareItemCraftEvent e) {
        for (ItemStack it : e.getInventory().getMatrix()) {
            if (isGem(it)) {
                e.getInventory().setResult(null);
                return;
            }
        }
    }

    // Creative-mode clicks use a different event, so watch it for bundles too.
    @EventHandler
    public void onCreative(InventoryCreativeEvent e) {
        if (e.getWhoClicked() instanceof Player p && (isBundle(e.getCursor()) || isBundle(e.getCurrentItem()))) {
            scheduleSweep(p);
        }
    }

    @EventHandler
    public void onClose(InventoryCloseEvent e) {
        if (e.getPlayer() instanceof Player p) scheduleSweep(p);
    }

    private void scheduleSweep(Player p) {
        Bukkit.getScheduler().runTask(plugin, () -> {
            if (p.isOnline()) sweepBundles(p);
        });
    }

    /** Pulls any gem out of any bundle the player carries and puts it back in their inventory. */
    public void sweepBundles(Player p) {
        PlayerInventory inv = p.getInventory();
        ItemStack[] contents = inv.getContents();
        for (int i = 0; i < contents.length; i++) {
            ItemStack it = contents[i];
            if (isBundle(it) && stripGems(p, it)) inv.setItem(i, it);
        }
        ItemStack cursor = p.getItemOnCursor();
        if (isBundle(cursor) && stripGems(p, cursor)) p.setItemOnCursor(cursor);
    }

    private boolean stripGems(Player p, ItemStack bundle) {
        if (!(bundle.getItemMeta() instanceof BundleMeta meta) || !meta.hasItems()) return false;
        List<ItemStack> keep = new ArrayList<>();
        List<ItemStack> removed = new ArrayList<>();
        for (ItemStack c : meta.getItems()) {
            if (isGem(c)) removed.add(c); else keep.add(c);
        }
        if (removed.isEmpty()) return false;

        meta.setItems(keep);
        bundle.setItemMeta(meta);
        for (ItemStack gem : removed) {
            for (ItemStack leftover : p.getInventory().addItem(gem).values()) {
                Item dropped = p.getWorld().dropItem(p.getLocation(), leftover);
                dropped.setUnlimitedLifetime(true);
                dropped.setInvulnerable(true);
            }
        }
        p.sendMessage(Component.text("Gems can't be stored in bundles.", NamedTextColor.RED));
        return true;
    }

    // Gems are kept on death. The server hands kept items back on respawn, so they can't be lost
    // even if the player disconnects while dead.
    @EventHandler
    public void onDeath(PlayerDeathEvent e) {
        Iterator<ItemStack> it = e.getDrops().iterator();
        while (it.hasNext()) {
            ItemStack drop = it.next();
            if (isGem(drop)) {
                e.getItemsToKeep().add(drop);
                it.remove();
            }
        }
    }
}
