package com.example.gems;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextColor;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.EnumMap;
import java.util.List;
import java.util.Map;

/** Builds the Bliss-style description shown on each gem item. */
public final class GemInfo {

    private record Ab(String name, String summary, String cdKey) {}
    private record Info(String quote, List<String> passives, List<Ab> abilities) {}

    private static final Map<GemType, Info> INFO = new EnumMap<>(GemType.class);

    private static void none(GemType t, String quote) {
        INFO.put(t, new Info(quote, List.of(), List.of()));
    }

    static {
        INFO.put(GemType.STRENGTH, new Info("Strength is taken, never given.",
                List.of("Strength I while held in your offhand",
                        "Specials: Burst Damage, Refractive Blood, Nulify, Smash Attack, Heavy Swing",
                        "Diminish: hitting a player weakens the nearest one",
                        "Hold sneak 1s: Sharpness V on a weapon in your offhand"),
                List.of(new Ab("Chad Strength", "every 4th crit does double damage", "strength.chad.cooldown-seconds"),
                        new Ab("Fractured", "halve damage taken and reflect it", "strength.fractured.cooldown-seconds"),
                        new Ab("Super Smash", "levitate, then slam the ground", "strength.smash.cooldown-seconds"),
                        new Ab("Frailer", "strip everyone else's buffs", "strength.frailer.cooldown-seconds"))));

        INFO.put(GemType.PUFF, new Info("Weightless, untouchable, gone.",
                List.of("No fall damage while held",
                        "Double jump",
                        "Permanent Speed",
                        "Upwind: every 15 sword hits lifts the target",
                        "Hold sneak 1s: Feather Falling IV on boots in your offhand"),
                List.of(new Ab("Dash", "launch through players in your path", "puff.dash.cooldown-seconds"),
                        new Ab("Puff Slam", "launch a target high and slam them down", "puff.slam.cooldown-seconds"),
                        new Ab("Tornado", "trap players in a tornado", "puff.tornado.cooldown-seconds"),
                        new Ab("Air Lock", "lock a player's utilities and jumps", "puff.airlock.cooldown-seconds"),
                        new Ab("Updraft", "rise, then slam down with a shockwave", "puff.updraft.cooldown-seconds"))));

        INFO.put(GemType.SPEED, new Info("Become a blur.",
                List.of("Speed I and II, alternating every second",
                        "Electrical Charge: every 16 sword hits strike",
                        "Temporal Pause: every 13 axe hits strike",
                        "Hold sneak 1s: Efficiency V on a tool in your offhand",
                        "Turbo: rain strengthens passives, thunder also halves cooldowns"),
                List.of(new Ab("Static Recall", "tag a player, then pull them to you", "speed.recall.cooldown-seconds"),
                        new Ab("Speedy Boi", "Speed, Haste and Regeneration", "speed.speedy.cooldown-seconds"),
                        new Ab("Blur", "your hits summon lightning", "speed.blur.cooldown-seconds"),
                        new Ab("Dazzling Stun", "strike and slow the 3 nearest players", "speed.dazzle.cooldown-seconds"),
                        new Ab("Overdrive", "every few sword hits summon lightning", "speed.overdrive.cooldown-seconds"))));

        none(GemType.FIRE, "Let it all burn.");
        none(GemType.LIFE, "Life finds a way.");
        none(GemType.ASTRA, "Beyond the stars.");
        none(GemType.TOMB, "Even the dead keep watch.");
        none(GemType.TIDE, "The tide answers to no one.");
        none(GemType.CRIMSON, "Blood remembers.");
        none(GemType.SPRING, "After the thaw, everything grows.");
        none(GemType.WEALTH, "Wealth to power an empire.");
        none(GemType.FROST, "Cold outlasts everything.");
    }

    private GemInfo() {}

    private static Component line(String text, TextColor color, boolean italic) {
        return Component.text(text, color).decoration(TextDecoration.ITALIC, italic);
    }

    public static List<Component> lore(GemType type, int selected, Player owner, GemsPlugin plugin) {
        Info info = INFO.get(type);
        List<Component> out = new ArrayList<>();
        out.add(line("\u201C" + info.quote() + "\u201D", NamedTextColor.GRAY, true));
        out.add(Component.empty());

        Energy energy = plugin.energy();
        if (energy != null && energy.enabled()) {
            int stage = owner == null ? 0 : energy.stage(owner.getUniqueId());
            out.add(line("Energy: ", NamedTextColor.GRAY, false)
                    .append(Component.text(Energy.stageName(stage), Energy.stageColor(stage))
                            .decoration(TextDecoration.ITALIC, false)));
            out.add(Component.empty());
        }

        if (!info.passives().isEmpty()) {
            out.add(line("Passives", NamedTextColor.GOLD, false));
            for (String s : info.passives()) out.add(line("- " + s, NamedTextColor.GRAY, false));
            out.add(Component.empty());
        }

        if (info.abilities().isEmpty()) {
            out.add(line("No abilities yet", NamedTextColor.GRAY, false));
        } else {
            double factor = (owner != null && energy != null) ? energy.cooldownFactor(owner) : 1.0;
            out.add(line("Abilities", NamedTextColor.GOLD, false));
            int sel = Math.floorMod(selected, info.abilities().size());
            for (int i = 0; i < info.abilities().size(); i++) {
                Ab a = info.abilities().get(i);
                double secs = plugin.getConfig().getDouble(a.cdKey(), 0.0) * factor;
                String text = (i == sel ? "> " : "  ") + a.name() + " - " + a.summary()
                        + " (" + Cooldowns.format((long) (secs * 1000.0)) + ")";
                out.add(line(text, i == sel ? type.color() : NamedTextColor.GRAY, false));
            }
        }
        return out;
    }
}
